"""Which tools a connection is told about, and the collapse/expand control.

The whole layer exists because an advertised tool list is **rent**: in a
stateless protocol the list is re-read at every step of every session, so a
registry that grows is paid for on every turn by every conversation, whether or
not the conversation uses those tools. The measured asymmetry is that one extra
*lookup round* costs roughly an order of magnitude more than one extra
advertised schema -- which makes hiding a name the wrong default for anything
used regularly, and advertising everything the wrong default for everything
else. Neither extreme is right, so this module is the policy in between, and
``measure.py`` is the arithmetic behind it.

Three facts shape the design and are worth stating before the code:

**Hiding is routing, never authority.** A name absent from ``tools/list`` is
still callable by exact name in a conforming server, and every confirmation,
cost, dry-run and acceptance gate still answers. A compressed surface must not
become a way to reach a tool that the caller was not allowed to reach.

**A client that refuses unlisted names makes the door mandatory.** Measured in
the source project: a real client answered "unknown tool" for a name that had
left the advertised set while the server would have dispatched it happily. So
the layer ships a generic per-name door (``mcp_tool_invoke``) and, for that
reason, lists it in *every* mode. A compressed surface whose lookup leads to an
uncallable name is worse than no compression.

**Selection must be a pure function of the view state.** No timeouts, no
laziness, no "recently used" heuristics: two connections with the same mode,
profile and level filter must list byte-identical sets, or a catalog answer
cannot be trusted to predict what a call will find.

The state machine below is CONNECTION-scoped, never conversation-scoped; a
stdio server sees a connection and the messages on it, not the conversations a
client multiplexes over it. That limitation is stated in ``status()`` rather
than papered over with a scope the server cannot observe.
"""

from __future__ import annotations

import hashlib
import json
import os
from collections.abc import Callable, Iterable, Mapping
from dataclasses import dataclass, field
from typing import Any

from .errors import (
    SpecError,
    SurfaceRequestError,
    UnknownToolName,
    ViewSwitchUnavailable,
)
from .model import ToolRecord, records_from_specs

#: The control/discovery entry points. They are declared here because they are
#: part of the view contract: every mode lists them, and ``status()`` names them
#: as the gateway core, so a project that renamed one would have to say so once.
DEFAULT_CATALOG_TOOL = "mcp_tool_catalog"
DEFAULT_VIEW_TOOL = "mcp_tool_view"
DEFAULT_INVOKE_TOOL = "mcp_tool_invoke"

#: The control kinds, positionally matched to ``SurfacePolicy.control_names``.
#: A project may declare fewer than three (a fixed-surface server needs no view
#: control), but never more, and the kinds stay in this order.
CONTROL_KINDS = ("catalog", "view", "invoke")

#: The reserved profile names. ``default`` is the bounded ordinary view (never
#: the complete registry) and ``all`` is the complete registry kept for
#: compatibility and debugging. They are reserved rather than declared because
#: every project needs exactly these two meanings, spelled the same way.
DEFAULT_PROFILE = "default"
ALL_PROFILE = "all"
RESERVED_PROFILES = (DEFAULT_PROFILE, ALL_PROFILE)

#: A fixed display set: the complete registry, no state, no filtering. Retained
#: because "the layer must be able to get out of the way" is a requirement, not
#: a nicety -- a caller debugging a missing tool needs one mode that hides
#: nothing.
MODE_STATIC = "static"
#: The bounded ordinary view, independent of any profile. **This is the default
#: exposure mode**: it is a plain, always-expanded list, so a client that cannot
#: handle `notifications/tools/list_changed` -- or a collapse/expand state machine
#: at all -- still starts from a usable set of entries. `dynamic` stays available
#: as an explicit opt-in for clients that do support the notification.
MODE_SEMANTIC = "semantic"
#: A named profile view.
MODE_PROFILE = "profile"
#: Collapse/expand over the other display sets, connection-scoped.
MODE_DYNAMIC = "dynamic"
#: The curated routing surface: control tools plus the representatives a normal
#: session actually needs, so the common task pays no lookup at all.
MODE_GATEWAY = "gateway"

VALID_EXPOSURE_MODES = (
    MODE_SEMANTIC,
    MODE_STATIC,
    MODE_PROFILE,
    MODE_DYNAMIC,
    MODE_GATEWAY,
)
VALID_EXPANDED_VIEWS = (MODE_STATIC, MODE_SEMANTIC, MODE_GATEWAY, MODE_PROFILE)
VALID_VIEW_ACTIONS = ("status", "set", "reset", "expand", "collapse")

#: The gateway is a routing surface, and its whole point is that it is small.
#: Listing an entry costs its schema every step; *not* listing it costs a lookup
#: round for the callers that need it. The measured break-even for a real tool
#: lands between roughly half and all sessions, so the entries are chosen by
#: measured use, not by taste. This reason string ships in ``status()`` so an
#: operator can see the trade rather than guess at it.
DEFAULT_GATEWAY_REASON = (
    "Curated representatives are listed because retrieval is not free (a lookup "
    "round re-reads the whole prefix while a listed entry rents its schema); "
    "everything else stays reachable by exact name or through the catalog."
)


@dataclass(frozen=True, slots=True)
class ProfileRule:
    """One named view: what it includes, and why a caller would pick it.

    Membership is declarative (name prefixes, exact names) with an optional
    predicate for the genuinely irregular case. A predicate is business code
    run by the layer, so it must be pure and cheap: it is called once per
    record per ``tools/list``.
    """

    name: str
    description: str = ""
    prefixes: tuple[str, ...] = ()
    names: frozenset[str] = frozenset()
    predicate: Callable[[ToolRecord], bool] | None = field(default=None, compare=False)

    def includes(self, record: ToolRecord) -> bool:
        if record.name in self.names:
            return True
        if self.prefixes and record.name.startswith(self.prefixes):
            return True
        if self.predicate is not None:
            return bool(self.predicate(record))
        return False


@dataclass(frozen=True, slots=True)
class SurfacePolicy:
    """Everything a project declares about how its registry is presented.

    This is the entire adaptation surface. A project that keeps its own registry
    and schemas supplies records and one of these; it does not fork the
    selection code, the state machine or the catalog.
    """

    profiles: tuple[ProfileRule, ...] = ()
    control_names: tuple[str, ...] = (
        DEFAULT_CATALOG_TOOL,
        DEFAULT_VIEW_TOOL,
        DEFAULT_INVOKE_TOOL,
    )
    #: The gateway's curated representatives, in listing order. Order is a
    #: routing decision ("grouped by what the caller does next"), so it is
    #: preserved rather than sorted.
    curated: tuple[str, ...] = ()
    #: Names kept registered so an existing caller keeps working after a merge,
    #: but no longer advertised outside the complete view. A compatibility path
    #: must not look like a normal choice.
    absorbed: frozenset[str] = frozenset()
    #: Names listed in every profile that includes their category, including
    #: under an explicit level filter. Reserved for session/observation tools
    #: whose absence would look like a broken server.
    always_visible: frozenset[str] = frozenset()
    #: The semantic tiers, cheapest-to-most-expensive is NOT implied: the tuple
    #: is just the vocabulary. ``rank_levels`` expresses preference. An EMPTY
    #: tuple is a legitimate declaration meaning "this project does not tier its
    #: tools": the level filter is then unavailable rather than advertised with
    #: names that mean nothing, which is the honest schema.
    levels: tuple[str, ...] = ("L1", "L2", "L3", "L4", "L5", "L6")
    #: Search tie-break order, most useful first. ``None`` is a legal member and
    #: means "a record with no declared level".
    rank_levels: tuple[str | None, ...] = ()
    #: One sentence per category, so a caller can route without reading a tool.
    category_purposes: Mapping[str, str] = field(default_factory=dict)
    #: Prescribed two-step (or longer) lookups, e.g. ``("docs_search",
    #: "docs_section")``. Used by :meth:`Surface.chain_violations`: a chain
    #: advertised half-way converts one lookup into two and is strictly worse
    #: than advertising both ends or neither.
    chains: tuple[tuple[str, ...], ...] = ()
    #: Allowed ``network`` values; empty means "do not constrain".
    networks: tuple[str, ...] = ()
    default_profile: str = DEFAULT_PROFILE
    #: Which display set an unqualified ``expand`` opens on a fresh dynamic
    #: connection. ``gateway`` is right when a curated set exists; a project
    #: whose registry is small enough that there is nothing worth curating
    #: (``curated=()``) wants ``static``, because otherwise "expand" would open a
    #: set identical to the collapsed one.
    default_expanded_view: str = MODE_GATEWAY
    gateway_reason: str = DEFAULT_GATEWAY_REASON

    def profile(self, name: str) -> ProfileRule | None:
        for rule in self.profiles:
            if rule.name == name:
                return rule
        return None

    def profile_names(self) -> tuple[str, ...]:
        return tuple(rule.name for rule in self.profiles)


class Surface:
    """A validated registry plus its presentation policy.

    Construction validates, because every invariant here fails *silently* at
    runtime otherwise: a curated name that is not registered would just never
    appear, and a profile listing that half-advertises a chain looks like a
    working server until a caller pays for the extra round.
    """

    def __init__(
        self,
        records: Iterable[ToolRecord | Mapping[str, Any]],
        policy: SurfacePolicy | None = None,
        *,
        validate: bool = True,
    ) -> None:
        self.policy = policy or SurfacePolicy()
        self.records = records_from_specs(records)
        self.by_name: dict[str, ToolRecord] = {record.name: record for record in self.records}
        if len(self.by_name) != len(self.records):
            raise SpecError("tool names must be unique")
        if validate:
            problems = self.problems()
            if problems:
                raise SpecError("; ".join(problems))

    # -- registry ----------------------------------------------------------

    def record(self, name: str) -> ToolRecord:
        """Resolve by exact name, advertised or not.

        This is the operation that makes hiding safe: it has no view filter on
        purpose, and it is the reference implementation of the rule the
        embedding server must keep -- a hidden known name stays callable.
        """
        try:
            return self.by_name[name]
        except KeyError:
            raise UnknownToolName(f"unknown tool name: {name!r}") from None

    def has(self, name: str) -> bool:
        return name in self.by_name

    def categories(self) -> tuple[str, ...]:
        seen: dict[str, None] = {}
        for record in self.records:
            seen.setdefault(record.category, None)
        return tuple(seen)

    def category_purpose(self, category: str) -> str:
        return str(self.policy.category_purposes.get(category, ""))

    # -- selection ---------------------------------------------------------

    @property
    def control_names(self) -> tuple[str, ...]:
        return tuple(self.policy.control_names)

    def control_kind(self, name: str) -> str | None:
        """Which control role a registered name plays, or ``None``.

        Positional, so a project that ships only catalog+invoke declares them in
        that order and gets the right routing without renaming anything.
        """
        try:
            index = self.policy.control_names.index(name)
        except ValueError:
            return None
        return CONTROL_KINDS[index] if index < len(CONTROL_KINDS) else None

    def control_records(self) -> tuple[ToolRecord, ...]:
        """The control tools, in declared order.

        A missing control name is simply absent: a project may ship the catalog
        and the per-name door without the view control, and the layer must not
        invent a tool it was not given.
        """
        return tuple(
            self.by_name[name] for name in self.control_names if name in self.by_name
        )

    def curated_records(self) -> tuple[ToolRecord, ...]:
        return tuple(
            self.by_name[name] for name in self.policy.curated if name in self.by_name
        )

    def gateway_records(self) -> tuple[ToolRecord, ...]:
        by_name = self.by_name
        ordered = list(self.control_names) + list(self.policy.curated)
        return tuple(by_name[name] for name in ordered if name in by_name)

    def _profile_includes(self, record: ToolRecord, profile: str) -> bool:
        if record.name in self.control_names:
            return True
        if profile in RESERVED_PROFILES:
            return True
        rule = self.policy.profile(profile)
        if rule is None:
            raise SurfaceRequestError(
                f"unknown profile {profile!r}; declared profiles: "
                f"{', '.join(RESERVED_PROFILES + self.policy.profile_names())}"
            )
        return rule.includes(record)

    def select(
        self,
        *,
        profile: str = DEFAULT_PROFILE,
        levels: Iterable[str] | None = None,
    ) -> tuple[ToolRecord, ...]:
        """The advertised set for one profile, optionally filtered by tier.

        The three filters, in order, and each one is deliberate:

        1. profile membership -- the coarse cut that keeps a session's context
           about the work it is doing;
        2. absorbed compatibility names, hidden in every profile but the
           complete one, because a compatibility path must not read as a normal
           choice;
        3. exposure/level. With no ``levels`` argument, a record declared
           ``default_exposure=False`` is hidden outside the complete profile.
           With a ``levels`` argument the caller has asked a question about
           tiers, so a record that declares a tier answers it and one that
           declares none stays -- the alternative would make an unlevelled tool
           permanently unreachable exactly when someone filters.
        """
        if profile not in RESERVED_PROFILES and self.policy.profile(profile) is None:
            raise SurfaceRequestError(
                f"unknown profile {profile!r}; declared profiles: "
                f"{', '.join(RESERVED_PROFILES + self.policy.profile_names())}"
            )
        selected_levels = set(levels or ())
        result: list[ToolRecord] = []
        for record in self.records:
            if not self._profile_includes(record, profile):
                continue
            if record.absorbed and profile != ALL_PROFILE:
                continue
            result.append(record)
        return tuple(
            record
            for record in result
            if self._level_admits(record, selected_levels, profile, levels is not None)
        )

    def _level_admits(
        self,
        record: ToolRecord,
        selected_levels: set[str],
        profile: str,
        levels_given: bool,
    ) -> bool:
        # The control/discovery entry points and the always-visible set survive
        # every level filter. A tier query is a question about domain tools; if
        # it could also hide `mcp_tool_view`, the filter would remove the only
        # advertised door back out of the narrowed view.
        if record.name in self.control_names or record.name in self.policy.always_visible:
            return True
        if levels_given:
            if record.level is None:
                return True
            return record.level in selected_levels
        if profile == ALL_PROFILE:
            return True
        return record.default_exposure

    def level(self, name: str) -> str | None:
        return self.record(name).level

    def chain_violations(self, advertised: Iterable[str]) -> tuple[dict[str, Any], ...]:
        """Prescribed lookups that the advertised set cuts in half.

        A two-step lookup whose first step is listed and second is not costs the
        caller the first step's rent *and* a lookup round -- strictly worse than
        listing both or neither. This is returned rather than raised because the
        right moment to fail is a project's own test, where the author sees the
        chain they just broke.
        """
        names = set(advertised)
        found: list[dict[str, Any]] = []
        for chain in self.policy.chains:
            present = [name for name in chain if name in names]
            if present and len(present) != len(chain):
                found.append(
                    {
                        "chain": list(chain),
                        "advertised": present,
                        "missing": [name for name in chain if name not in names],
                    }
                )
        return tuple(found)

    # -- identity ----------------------------------------------------------

    def fingerprint(self) -> str:
        """A stable hash of what the registry *advertises*.

        Every description edit moves it, which is the point: a stored
        fingerprint that did not move would have to be maintained by hand, and a
        hand-maintained one is wrong the first time someone forgets. Computed
        over a canonical form, so it does not depend on declaration order or on
        ``PYTHONHASHSEED``.
        """
        canonical = [
            {
                "name": record.name,
                "description": record.description,
                "category": record.category,
                "level": record.level,
                "keywords": sorted(record.keywords),
                "mutating": record.mutating,
                "dryRun": record.dry_run,
                "defaultExposure": record.default_exposure,
                "absorbed": record.absorbed,
                "sideEffects": sorted(record.side_effects),
                "schemaKeys": sorted(
                    str(key) for key in (record.input_schema.get("properties") or {})
                ),
            }
            for record in sorted(self.records, key=lambda item: item.name)
        ]
        blob = json.dumps(canonical, sort_keys=True, separators=(",", ":")).encode("utf-8")
        return hashlib.sha256(blob).hexdigest()

    # -- validation --------------------------------------------------------

    def problems(self) -> tuple[str, ...]:
        """Every declaration fault, all at once.

        All at once rather than first-one-wins: a project adapting this layer
        typically has several typos on the first pass, and repairing them one
        exception per run is how an adaptation is abandoned.
        """
        found: list[str] = []
        policy = self.policy

        if not policy.control_names:
            found.append("control_names must declare at least one registered tool")
        if len(policy.control_names) > len(CONTROL_KINDS):
            found.append(
                f"control_names can declare at most {len(CONTROL_KINDS)} tools "
                f"({', '.join(CONTROL_KINDS)})"
            )
        if len(set(policy.control_names)) != len(policy.control_names):
            found.append("control_names must be distinct")
        for name in policy.control_names:
            if name not in self.by_name:
                found.append(f"control tool {name!r} is not registered")

        seen_curated: set[str] = set()
        for name in policy.curated:
            if name in seen_curated:
                found.append(f"curated entry {name!r} is declared twice")
            seen_curated.add(name)
            if name not in self.by_name:
                found.append(f"curated entry {name!r} is not registered")
            elif name in policy.control_names:
                found.append(f"curated entry {name!r} is already a control tool")
            elif name in policy.absorbed:
                found.append(
                    f"curated entry {name!r} is a compatibility wrapper and must not be curated"
                )

        for name in sorted(policy.absorbed):
            if name not in self.by_name:
                found.append(f"absorbed name {name!r} is not registered")
        for name in sorted(policy.always_visible):
            if name not in self.by_name:
                found.append(f"always_visible name {name!r} is not registered")

        if len(set(policy.levels)) != len(policy.levels) or any(
            not isinstance(level, str) or not level for level in policy.levels
        ):
            found.append("levels must be unique non-empty strings (or empty)")
        for level in policy.rank_levels:
            if level is not None and level not in policy.levels:
                found.append(f"rank_levels entry {level!r} is not a declared level")

        rule_names = policy.profile_names()
        if len(set(rule_names)) != len(rule_names):
            found.append("profile names must be unique")
        for reserved in RESERVED_PROFILES:
            if reserved in rule_names:
                found.append(f"profile name {reserved!r} is reserved and cannot be redeclared")
        if policy.default_profile not in RESERVED_PROFILES and (
            policy.default_profile not in rule_names
        ):
            found.append(f"default_profile {policy.default_profile!r} is not declared")
        if policy.default_expanded_view not in VALID_EXPANDED_VIEWS:
            found.append(
                "default_expanded_view must be one of: "
                f"{', '.join(VALID_EXPANDED_VIEWS)}"
            )

        known_profiles = set(RESERVED_PROFILES) | set(rule_names)
        for record in self.records:
            if record.level is not None and record.level not in policy.levels:
                found.append(
                    f"{record.name}: level {record.level!r} is not in the declared levels"
                )
            for profile in record.profiles:
                if profile not in known_profiles:
                    found.append(f"{record.name}: unknown profile {profile!r}")
            if policy.networks and record.network not in policy.networks:
                found.append(
                    f"{record.name}: network {record.network!r} is not one of "
                    f"{', '.join(policy.networks)}"
                )

        known_categories = set(self.categories())
        for category in policy.category_purposes:
            if category not in known_categories:
                found.append(
                    f"category purpose declared for unknown category {category!r}"
                )

        for chain in policy.chains:
            if len(chain) < 2:
                found.append(f"prescribed chain {list(chain)!r} must have at least two steps")
            for name in chain:
                if name not in self.by_name:
                    found.append(f"prescribed chain step {name!r} is not registered")
        return tuple(found)

    def audit(self) -> dict[str, Any]:
        """Derived facts an adapting project can assert on, all cheap to compute."""
        default_names = [record.name for record in self.select(profile=DEFAULT_PROFILE)]
        gateway_names = [record.name for record in self.gateway_records()]
        return {
            "registryCount": len(self.records),
            "defaultVisible": len(default_names),
            "gatewayEntries": len(gateway_names),
            "hiddenOutsideAll": len(self.records) - len(self.select(profile=ALL_PROFILE)),
            "categories": list(self.categories()),
            "profiles": list(self.policy.profile_names()),
            "chainViolationsInGateway": list(self.chain_violations(gateway_names)),
            "chainViolationsInDefault": list(self.chain_violations(default_names)),
            "fingerprint": self.fingerprint(),
        }

    # -- state -------------------------------------------------------------

    def view(
        self,
        *,
        mode: str | None = None,
        profile: str | None = None,
        levels: Iterable[str] | None = None,
        environ: Mapping[str, str] | None = None,
        env_prefix: str = "MCP_TOOL_",
    ) -> "ToolViewState":
        """Build this connection's view state.

        The environment is consulted only here and only for the two deployment
        switches that a bridge owns (an operator cannot edit someone else's
        registry, so a mode that can only be set in code is not configurable).
        File-based configuration stays in the business: where a config file
        lives is a deployment fact, not a library fact.
        """
        resolved_mode = resolve_exposure(
            mode=mode, environ=environ, env_prefix=env_prefix
        )
        if resolved_mode == MODE_STATIC:
            resolved_profile = ALL_PROFILE
        elif resolved_mode in {MODE_PROFILE, MODE_DYNAMIC}:
            resolved_profile = profile or resolve_startup_profile(
                environ=environ,
                env_prefix=env_prefix,
                default=self.policy.default_profile,
            )
        else:
            resolved_profile = DEFAULT_PROFILE
        if resolved_profile not in RESERVED_PROFILES and self.policy.profile(
            resolved_profile
        ) is None:
            raise SurfaceRequestError(
                f"unknown profile {resolved_profile!r}; declared profiles: "
                f"{', '.join(RESERVED_PROFILES + self.policy.profile_names())}"
            )
        return ToolViewState(
            surface=self,
            mode=resolved_mode,
            profile=resolved_profile,
            semantic_levels=tuple(levels) if levels is not None else None,
            # A fresh dynamic connection advertises NO domain schema: it starts
            # collapsed on the control/discovery entry points and remembers the
            # policy's default expanded set for an unqualified expand. Every
            # other mode has no collapse state and lists its own fixed set.
            collapsed=resolved_mode == MODE_DYNAMIC,
            expanded_view=self.policy.default_expanded_view,
        )


def _validate_levels(levels: Iterable[str], declared: tuple[str, ...]) -> tuple[str, ...]:
    if isinstance(levels, (str, bytes)):
        raise SurfaceRequestError("semantic_levels must be a list of level names")
    if not declared:
        raise SurfaceRequestError(
            "this surface declares no semantic levels, so semantic_levels cannot be used"
        )
    given = list(levels)
    if not given:
        raise SurfaceRequestError("semantic_levels must be a non-empty list")
    for level in given:
        if not isinstance(level, str) or level not in declared:
            raise SurfaceRequestError(
                f"semantic_levels must contain only: {', '.join(declared)}"
            )
    if len(set(given)) != len(given):
        raise SurfaceRequestError("semantic_levels must not contain duplicates")
    return tuple(sorted(set(given), key=declared.index))


def resolve_exposure(
    *,
    mode: str | None = None,
    environ: Mapping[str, str] | None = None,
    env_prefix: str = "MCP_TOOL_",
    default: str = MODE_SEMANTIC,
) -> str:
    """Explicit argument, then the environment, then the default.

    The default is ``semantic`` -- an always-expanded bounded list -- because the
    default has to be the mode that works for **every** client. Collapsing is a
    capability (the client must both understand a `tools/list` that changes and
    honour `notifications/tools/list_changed`), so `dynamic` is opt-in: a project
    whose callers all support it declares that, rather than making every other
    client start from three control tools and a lookup round.

    Precedence is stated here rather than in the business because getting it
    backwards is the classic deployment bug: an operator sets the variable, the
    code's argument silently wins, and the switch "does not work".
    """
    env = os.environ if environ is None else environ
    variable = f"{env_prefix}EXPOSURE"
    value: Any = mode
    if value is None:
        value = env.get(variable, default)
    if not isinstance(value, str):
        raise SurfaceRequestError("the exposure mode must be a string")
    value = value.strip().lower()
    if value not in VALID_EXPOSURE_MODES:
        raise SurfaceRequestError(
            f"{variable} must be one of: {', '.join(VALID_EXPOSURE_MODES)}"
        )
    return value


def resolve_startup_profile(
    *,
    profile: str | None = None,
    environ: Mapping[str, str] | None = None,
    env_prefix: str = "MCP_TOOL_",
    default: str = DEFAULT_PROFILE,
) -> str:
    env = os.environ if environ is None else environ
    variable = f"{env_prefix}PROFILE"
    value: Any = profile
    if value is None:
        value = env.get(variable, default)
    if not isinstance(value, str):
        raise SurfaceRequestError("the startup profile must be a string")
    return value.strip().lower()


@dataclass(slots=True)
class ToolViewState:
    """One connection's display state, and the control that changes it.

    SCOPE: connection-scoped, never conversation-scoped. A stdio server sees a
    connection and its messages, not the conversations a client multiplexes over
    it, so an expand performed for one conversation is observed by every
    conversation on the same connection. ``status()`` says ``scope:
    "connection"`` instead of claiming an isolation the server cannot see.

    Collapse is pure in-memory state: it writes nothing locally or remotely and
    is not the same as exiting a browser or revoking a permission.
    """

    surface: Surface
    mode: str
    profile: str
    semantic_levels: tuple[str, ...] | None = None
    initial_profile: str | None = None
    collapsed: bool = False
    expanded_view: str = MODE_GATEWAY

    def __post_init__(self) -> None:
        if self.mode not in VALID_EXPOSURE_MODES:
            raise SurfaceRequestError(
                f"exposure mode must be one of: {', '.join(VALID_EXPOSURE_MODES)}"
            )
        if self.initial_profile is None:
            self.initial_profile = self.profile
        if self.expanded_view not in VALID_EXPANDED_VIEWS:
            raise SurfaceRequestError(
                f"expanded_view must be one of: {', '.join(VALID_EXPANDED_VIEWS)}"
            )

    @property
    def switching_available(self) -> bool:
        return self.mode == MODE_DYNAMIC

    @property
    def list_changed_capability(self) -> bool:
        return self.switching_available

    @property
    def state(self) -> str:
        return "collapsed" if self.mode == MODE_DYNAMIC and self.collapsed else "expanded"

    # -- advertised set ----------------------------------------------------

    def listed(self) -> tuple[ToolRecord, ...]:
        surface = self.surface
        if self.mode == MODE_STATIC:
            return surface.records
        if self.mode == MODE_GATEWAY:
            return surface.gateway_records()
        if self.mode == MODE_DYNAMIC:
            if self.collapsed:
                return surface.control_records()
            if self.expanded_view == MODE_STATIC:
                return surface.records
            if self.expanded_view == MODE_GATEWAY:
                return surface.gateway_records()
            if self.expanded_view == MODE_SEMANTIC:
                return surface.select(profile=DEFAULT_PROFILE, levels=self.semantic_levels)
            return surface.select(profile=self.profile, levels=self.semantic_levels)
        return surface.select(profile=self.profile, levels=self.semantic_levels)

    def listed_names(self) -> tuple[str, ...]:
        return tuple(record.name for record in self.listed())

    def is_listed(self, name: str) -> bool:
        return name in set(self.listed_names())

    def advertised(self) -> list[dict[str, Any]]:
        """The exact ``tools/list`` result for this connection."""
        return [record.advertised() for record in self.listed()]

    def status(self) -> dict[str, Any]:
        """The state report. Every field is a claim a caller can act on.

        ``conventionOnly`` and ``authorityChanged`` are not decoration: the
        first says this whole mechanism is a display convention, and the second
        says collapsing changed no permission. ``hiddenNamesStillCallable``
        pairs with them -- a caller that reads only this object must be able to
        conclude that a hidden name is still reachable.
        """
        listed = self.listed()
        return {
            "exposureMode": self.mode,
            "state": self.state,
            "expandedView": self.expanded_view,
            "scope": "connection",
            "profile": self.profile,
            "semanticLevels": list(self.semantic_levels or ()),
            "toolCount": len(listed),
            "registryCount": len(self.surface.records),
            "listedNames": [record.name for record in listed],
            "hiddenNamesStillCallable": True,
            "gateway": {
                "core": list(self.surface.control_names),
                "curated": list(self.surface.policy.curated),
                "reason": self.surface.policy.gateway_reason,
            },
            "switchingAvailable": self.switching_available,
            "listChangedCapability": self.list_changed_capability,
            "conventionOnly": True,
            "authorityChanged": False,
            "knownNameCallsRemainAvailable": True,
            "profiles": [
                {"name": name, "description": self._profile_description(name)}
                for name in RESERVED_PROFILES + self.surface.policy.profile_names()
            ],
        }

    def _profile_description(self, name: str) -> str:
        if name == ALL_PROFILE:
            return "Complete tool registry for compatibility and debugging."
        if name == DEFAULT_PROFILE:
            return (
                "Ordinary bounded view: every category, without hidden or "
                "compatibility names."
            )
        rule = self.surface.policy.profile(name)
        return rule.description if rule is not None else ""

    # -- control -----------------------------------------------------------

    def _effective_state(self) -> tuple[Any, ...]:
        """Everything whose change actually alters what ``tools/list`` returns."""
        return (self.collapsed, self.expanded_view, self.profile, self.semantic_levels)

    def apply(self, arguments: Mapping[str, Any] | None = None) -> tuple[dict[str, Any], bool]:
        """Perform one view action; return ``(payload, changed)``.

        ``changed`` is what the embedding server needs to decide whether to send
        ``notifications/tools/list_changed``: a ``status`` or a no-op ``expand``
        must not wake every conversation on the connection.
        """
        args = dict(arguments or {})
        action = args.get("action", "status")
        if action not in VALID_VIEW_ACTIONS:
            raise SurfaceRequestError(
                f"action must be one of: {', '.join(VALID_VIEW_ACTIONS)}"
            )
        if action == "status":
            return {**self.status(), "changed": False, "refreshRequired": False}, False
        if not self.switching_available:
            raise ViewSwitchUnavailable(
                "tool view switching requires the dynamic exposure mode; "
                f"the current mode is {self.mode!r}, a fixed view"
            )
        before = self._effective_state()
        if action == "reset":
            self.collapsed = True
            self.expanded_view = self.surface.policy.default_expanded_view
            self.profile = self.initial_profile or DEFAULT_PROFILE
            self.semantic_levels = None
        elif action == "collapse":
            self.collapsed = True
        else:
            requested = args.get("expanded_view")
            if requested is None:
                requested = MODE_PROFILE if action == "set" else self.expanded_view
            if not isinstance(requested, str) or requested not in VALID_EXPANDED_VIEWS:
                raise SurfaceRequestError(
                    f"expanded_view must be one of: {', '.join(VALID_EXPANDED_VIEWS)}"
                )
            self.expanded_view = requested
            profile = args.get("profile")
            if profile is not None:
                if not isinstance(profile, str):
                    raise SurfaceRequestError("profile must be a string")
                profile = profile.strip().lower()
                if profile not in RESERVED_PROFILES and self.surface.policy.profile(
                    profile
                ) is None:
                    raise SurfaceRequestError(
                        f"unknown profile {profile!r}; declared profiles: "
                        f"{', '.join(RESERVED_PROFILES + self.surface.policy.profile_names())}"
                    )
                self.profile = profile
            levels = args.get("semantic_levels")
            if levels is not None:
                self.semantic_levels = _validate_levels(
                    levels, self.surface.policy.levels
                )
            elif action == "set":
                # The legacy ``set`` action always resolved its filter from the
                # call, so an omitted level list means "no filter", not "keep".
                self.semantic_levels = None
            self.collapsed = False
        changed = before != self._effective_state()
        return {
            **self.status(),
            "changed": changed,
            "refreshRequired": changed,
            "notification": "notifications/tools/list_changed" if changed else None,
        }, changed
