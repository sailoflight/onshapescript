"""Compressed MCP tool surfaces: views, gateway curation, catalog lookup, cost.

Importing this package has no side effects: it reads no environment variable,
touches no file, opens no socket and imports no MCP SDK. A project supplies its
registry as data and gets back selection, a connection-scoped collapse/expand
state machine, a bounded catalog and the arithmetic behind a curation decision.

What it is not:

* not an MCP server, transport, or session manager -- the embedding project
  owns the protocol and its handlers;
* not a second registry -- the project keeps its own tool definitions and
  passes them in, and the layer never rewrites a schema it did not author;
* not an authority change -- hiding a name is context routing, and every
  confirmation, cost, dry-run and acceptance gate still answers.

Minimal adaptation::

    from mcp_surface import ProfileRule, SurfacePolicy, ToolCatalog, bootstrap

    policy = SurfacePolicy(
        profiles=(ProfileRule("model", "Modelling tools.", prefixes=("mesh_",)),),
        curated=("mesh_run", "mesh_inspect"),
        chains=(("docs_search", "docs_section"),),
    )
    surface, catalog, state = bootstrap(my_tool_payloads, policy)
    advertised = state.advertised()          # what tools/list returns: this
                                             # project's default mode, expanded
    catalog.dispatch({"action": "search", "query": "render"})

Pass ``mode="dynamic"`` only when every caller can handle a `tools/list` that
changes (and the matching `notifications/tools/list_changed`). The library's
default is the always-expanded bounded view, because compatibility with unknown
clients is the one property a library default cannot assume away; a project
whose registry is large enough to have a curated set can start from ``gateway``
instead by declaring ``SurfacePolicy(default_exposure="gateway")`` -- that is a
fixed, always-expanded page too.

See ``docs/ADAPTATION_GUIDE.md`` for the full contract, and ``DESIGN.md`` for
why the layer is shaped this way.
"""

from __future__ import annotations

from .catalog import (
    DEFAULT_INDEX_RESULTS,
    DEFAULT_SEARCH_RESULTS,
    MAX_INDEX_RESULTS,
    MAX_SEARCH_RESULTS,
    ToolCatalog,
)
from .control import (
    CATALOG_ACTIONS,
    CONTROL_TOOL_KINDS,
    bootstrap,
    control_tool_definitions,
    dispatch_control,
)
from .errors import (
    McpSurfaceError,
    SpecError,
    SurfaceRequestError,
    UnknownToolName,
    ViewSwitchUnavailable,
)
from .measure import (
    DEFAULT_CHARS_PER_TOKEN,
    DEFAULT_GROWTH_TOKENS,
    DEFAULT_PREFIX_TOKENS,
    DEFAULT_STEPS,
    SessionModel,
    SurfaceSize,
    audit_surface,
    break_even_expected_use,
    chain_violations,
    compact_json,
    curation_review,
    entry_rent,
    estimate_tokens,
    lookup_round_cost,
    session_cost,
    size_of_records,
    surface_size,
    view_report,
    widening_ratio,
)
from .model import (
    CONFIRMATION_ALWAYS,
    CONFIRMATION_MODES,
    CONFIRMATION_NONE,
    CONFIRMATION_NON_DRY_RUN,
    CONFIRMATION_RUNTIME_REQUIRED,
    ToolRecord,
    compact,
    confirmation_mode,
    records_from_specs,
    tokenize,
)
from .views import (
    ALL_PROFILE,
    CONTROL_KINDS,
    DEFAULT_CATALOG_TOOL,
    DEFAULT_INVOKE_TOOL,
    DEFAULT_PROFILE,
    DEFAULT_VIEW_TOOL,
    MODE_DYNAMIC,
    MODE_GATEWAY,
    MODE_PROFILE,
    MODE_SEMANTIC,
    MODE_STATIC,
    RESERVED_PROFILES,
    VALID_EXPANDED_VIEWS,
    VALID_EXPOSURE_MODES,
    VALID_VIEW_ACTIONS,
    ProfileRule,
    Surface,
    SurfacePolicy,
    ToolViewState,
    resolve_exposure,
    resolve_startup_profile,
)

__version__ = "0.1.0.dev4"

__all__ = [
    # model
    "CONFIRMATION_ALWAYS",
    "CONFIRMATION_MODES",
    "CONFIRMATION_NONE",
    "CONFIRMATION_NON_DRY_RUN",
    "CONFIRMATION_RUNTIME_REQUIRED",
    "ToolRecord",
    "compact",
    "confirmation_mode",
    "records_from_specs",
    "tokenize",
    # views
    "ALL_PROFILE",
    "CONTROL_KINDS",
    "DEFAULT_CATALOG_TOOL",
    "DEFAULT_INVOKE_TOOL",
    "DEFAULT_PROFILE",
    "DEFAULT_VIEW_TOOL",
    "MODE_DYNAMIC",
    "MODE_GATEWAY",
    "MODE_PROFILE",
    "MODE_SEMANTIC",
    "MODE_STATIC",
    "RESERVED_PROFILES",
    "VALID_EXPANDED_VIEWS",
    "VALID_EXPOSURE_MODES",
    "VALID_VIEW_ACTIONS",
    "ProfileRule",
    "Surface",
    "SurfacePolicy",
    "ToolViewState",
    "resolve_exposure",
    "resolve_startup_profile",
    # catalog
    "DEFAULT_INDEX_RESULTS",
    "DEFAULT_SEARCH_RESULTS",
    "MAX_INDEX_RESULTS",
    "MAX_SEARCH_RESULTS",
    "ToolCatalog",
    # control
    "CATALOG_ACTIONS",
    "CONTROL_TOOL_KINDS",
    "bootstrap",
    "control_tool_definitions",
    "dispatch_control",
    # measure
    "DEFAULT_CHARS_PER_TOKEN",
    "DEFAULT_GROWTH_TOKENS",
    "DEFAULT_PREFIX_TOKENS",
    "DEFAULT_STEPS",
    "SessionModel",
    "SurfaceSize",
    "audit_surface",
    "break_even_expected_use",
    "chain_violations",
    "compact_json",
    "curation_review",
    "entry_rent",
    "estimate_tokens",
    "lookup_round_cost",
    "session_cost",
    "size_of_records",
    "surface_size",
    "view_report",
    "widening_ratio",
    # errors
    "McpSurfaceError",
    "SpecError",
    "SurfaceRequestError",
    "UnknownToolName",
    "ViewSwitchUnavailable",
    # package
    "__version__",
]
