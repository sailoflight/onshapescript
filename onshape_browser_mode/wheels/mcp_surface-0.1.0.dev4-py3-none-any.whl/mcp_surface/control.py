"""The three control tools, as definitions and as one reusable dispatcher.

A compressed surface owes the caller three doors, and shipping them as data is
most of what "write it once" means in practice -- the alternative is that every
project retypes the same schemas and gets the argument names subtly different
from the catalog it advertises.

``mcp_tool_catalog``
    Discovery: index, search, describe, status.
``mcp_tool_view``
    This connection's display state, and the collapse/expand control in the
    dynamic mode.
``mcp_tool_invoke``
    The per-name door. It exists because "hidden known-name calls remain
    available" is a property of the *server*, not of every client: a client that
    refuses a name absent from ``tools/list`` cannot reach a hidden tool at all
    unless some advertised name forwards to it. This door forwards to the same
    handler, and therefore to the same confirmation, cost, dry-run and
    acceptance gates -- it is never a way around a gate.

``dispatch_control`` below is pure routing over plain dictionaries. It does not
speak MCP, and it raises :class:`~mcp_surface.errors.SurfaceRequestError` for a
bad call rather than inventing a wire-level error shape.
"""

from __future__ import annotations

from collections.abc import Callable, Iterable, Mapping
from typing import Any

from .catalog import ToolCatalog
from .errors import SurfaceRequestError
from .model import ToolRecord
from .views import (
    ALL_PROFILE,
    CONTROL_KINDS,
    DEFAULT_CATALOG_TOOL,
    DEFAULT_INVOKE_TOOL,
    DEFAULT_PROFILE,
    DEFAULT_VIEW_TOOL,
    VALID_EXPANDED_VIEWS,
    VALID_VIEW_ACTIONS,
    Surface,
    SurfacePolicy,
    ToolViewState,
)

CONTROL_TOOL_KINDS = CONTROL_KINDS

CATALOG_ACTIONS = ("index", "search", "describe", "status")

#: The catalog schema's `limit` ceiling is published so a caller can see the cap
#: rather than discover it by being truncated.
_MAX_LIMIT = 40

_INVOKE_DESCRIPTION = (
    "Call ANY registered tool by exact name, listed or not. A compressed "
    "tools/list is a display convention: every registered name stays callable "
    "and every confirmation, cost, dry-run and acceptance gate still answers. "
    "Use this when a catalog answer named a tool that your client refuses to "
    "call because it is not advertised."
)

_VIEW_DESCRIPTION = (
    "Report and change THIS CONNECTION's advertised tool set. State is "
    "connection-scoped: a client that shares one connection shares the view. "
    "Collapse is display state only -- it revokes nothing, and hidden names "
    "remain callable by exact name."
)

_CATALOG_DESCRIPTION = (
    "Bounded discovery over the tool registry. index answers which names and "
    "categories exist, search scores matches, describe returns the exact input "
    "schema, status reports sizes and identity. Nothing here is a capability of "
    "its own."
)


def _catalog_definition(name: str, surface: Surface) -> dict[str, Any]:
    return {
        "name": name,
        "description": _CATALOG_DESCRIPTION,
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": list(CATALOG_ACTIONS),
                    "default": "index",
                    "description": "index|search|describe|status",
                },
                "query": {
                    "type": "string",
                    "description": "search text; required for action=search",
                },
                "category": {
                    "type": "string",
                    "enum": list(surface.categories()),
                    "description": "restrict index or search to one category",
                },
                "name": {
                    "type": "string",
                    "description": "exact tool name; required for action=describe",
                },
                "limit": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": _MAX_LIMIT,
                    "description": "bounded page size; the server caps it",
                },
            },
            "additionalProperties": False,
        },
    }


def _view_definition(name: str, surface: Surface) -> dict[str, Any]:
    profiles = [DEFAULT_PROFILE, ALL_PROFILE] + list(surface.policy.profile_names())
    properties: dict[str, Any] = {
        "action": {
            "type": "string",
            "enum": list(VALID_VIEW_ACTIONS),
            "default": "status",
        },
        "expanded_view": {
            "type": "string",
            "enum": list(VALID_EXPANDED_VIEWS),
            "description": "which display set an expand opens",
        },
        "profile": {"type": "string", "enum": profiles},
    }
    if surface.policy.levels:
        # An empty vocabulary means the project does not tier its tools, so the
        # filter is not advertised at all: an enum of invented names would be a
        # schema that lies about what the caller may ask for.
        properties["semantic_levels"] = {
            "type": "array",
            "items": {"type": "string", "enum": list(surface.policy.levels)},
            "minItems": 1,
            "uniqueItems": True,
        }
    return {
        "name": name,
        "description": _VIEW_DESCRIPTION,
        "inputSchema": {
            "type": "object",
            "properties": properties,
            "additionalProperties": False,
        },
    }


def _invoke_definition(name: str) -> dict[str, Any]:
    return {
        "name": name,
        "description": _INVOKE_DESCRIPTION,
        "inputSchema": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "exact registered tool name"},
                "arguments": {
                    "type": "object",
                    "description": "arguments for that tool's own schema",
                    "additionalProperties": True,
                },
            },
            "required": ["name"],
            "additionalProperties": False,
        },
    }


def control_tool_definitions(surface: Surface) -> list[dict[str, Any]]:
    """The declared control tool objects, with schemas derived from the policy.

    The ``profile``, ``semantic_levels`` and ``category`` enumerations are read
    out of the project's own declaration, so a profile renamed in one place
    cannot stay stale in the schema a client validates against.
    """
    definitions: list[dict[str, Any]] = []
    for name in surface.control_names:
        if name not in surface.by_name:
            continue
        kind = surface.control_kind(name)
        if kind == "catalog":
            definitions.append(_catalog_definition(name, surface))
        elif kind == "view":
            definitions.append(_view_definition(name, surface))
        elif kind == "invoke":
            definitions.append(_invoke_definition(name))
    return definitions


def dispatch_control(
    name: str,
    arguments: Mapping[str, Any] | None,
    *,
    surface: Surface,
    catalog: ToolCatalog,
    state: ToolViewState,
    invoke: Callable[[str, Mapping[str, Any]], Any] | None = None,
) -> dict[str, Any]:
    """Route one call to a control tool.

    ``invoke`` is the embedding server's own dispatcher. When it is supplied the
    door forwards into it, which is the whole point: one entry point that
    reaches the *same* handler as a directly advertised call. When it is not
    supplied -- a contract test, or a project wiring the door separately -- the
    result is an explicit forwarding instruction rather than a silent no-op.
    """
    args = dict(arguments or {})
    kind = surface.control_kind(name)
    if kind == "catalog":
        return catalog.dispatch(args, view=state)
    if kind == "view":
        payload, _changed = state.apply(args)
        return payload
    if kind == "invoke":
        target = args.get("name")
        if not isinstance(target, str) or not target.strip():
            raise SurfaceRequestError("invoke requires a non-empty 'name'")
        forwarded = args.get("arguments") or {}
        if not isinstance(forwarded, Mapping):
            raise SurfaceRequestError("invoke 'arguments' must be an object")
        record = surface.record(target)
        if invoke is not None:
            return {
                "action": "invoke",
                "tool": record.name,
                "forwarded": True,
                "result": invoke(record.name, forwarded),
            }
        return {
            "action": "invoke",
            "tool": record.name,
            "arguments": dict(forwarded),
            "forwarded": False,
            "note": (
                "Route these arguments to the registered handler for this name. "
                "The tool's own confirmation, cost and acceptance gates apply "
                "unchanged; the view never widens authority."
            ),
        }
    raise SurfaceRequestError(f"not a control tool: {name!r}")


def bootstrap(
    records: Iterable[ToolRecord | Mapping[str, Any]],
    policy: SurfacePolicy | None = None,
    *,
    mode: str | None = None,
    profile: str | None = None,
    levels: Iterable[str] | None = None,
    environ: Mapping[str, str] | None = None,
    env_prefix: str = "MCP_TOOL_",
    catalog: ToolCatalog | None = None,
) -> tuple[Surface, ToolCatalog, ToolViewState]:
    """Build the validated surface, its catalog and one connection's view state.

    One call, because the three objects are useless apart and a server that
    constructs them in the wrong order gets a state whose registry it cannot
    search. Validation happens here, at startup, where a mistake is a crash
    instead of a mysteriously missing tool in one session.
    """
    surface = Surface(records, policy)
    resolved_catalog = catalog or ToolCatalog(surface)
    state = surface.view(
        mode=mode, profile=profile, levels=levels, environ=environ, env_prefix=env_prefix
    )
    return surface, resolved_catalog, state


__all__ = [
    "CATALOG_ACTIONS",
    "CONTROL_TOOL_KINDS",
    "DEFAULT_CATALOG_TOOL",
    "DEFAULT_INVOKE_TOOL",
    "DEFAULT_VIEW_TOOL",
    "bootstrap",
    "control_tool_definitions",
    "dispatch_control",
]
