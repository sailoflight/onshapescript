"""One registered tool, as data.

A tool surface is compressed by *selection*: the registry keeps every tool, and
a view decides which subset is advertised on a connection. That only works if
the selection rules can see structured facts about a tool -- its category, its
semantic tier, whether it mutates, whether it has a schema-level confirmation
gate -- and not just a name.

This module is where those facts live. It deliberately does not import any MCP
SDK and does not know what a transport is: a :class:`ToolRecord` wraps the raw
tool dictionary a server would put in ``tools/list`` (``payload``) and adds the
selection metadata around it. The business keeps owning its registry, its
handlers and its schemas; it hands the layer records and gets advertised
payloads back.

Derived facts are derived, never declared twice:

``search_tokens``
    Tokenized once from the name, keywords, category and description, so
    catalog search cannot drift from the text a caller actually reads.
``confirmation_mode``
    Read out of the tool's own JSON Schema rather than maintained as a separate
    list, so a schema edit silently changing when a mutation is confirmed also
    changes what the catalog reports.
"""

from __future__ import annotations

import re
from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field
from typing import Any

from .errors import SpecError

#: A confirmation state shared by every tool that takes mutations. ``none``
#: means the tool has no ``confirm_mutation`` property at all -- not that it is
#: safe. The distinction matters: a read-only tool and a mutating tool with no
#: gate both answer ``none`` today, and the second one is a bug the catalog
#: should show rather than hide.
CONFIRMATION_NONE = "none"
CONFIRMATION_ALWAYS = "always"
CONFIRMATION_NON_DRY_RUN = "non_dry_run"
CONFIRMATION_RUNTIME_REQUIRED = "runtime_required"

CONFIRMATION_MODES = (
    CONFIRMATION_NONE,
    CONFIRMATION_ALWAYS,
    CONFIRMATION_NON_DRY_RUN,
    CONFIRMATION_RUNTIME_REQUIRED,
)

_TOKEN = re.compile(r"[a-z0-9]+")

#: Keys the selection layer reads out of a raw tool payload. Everything else in
#: the payload is passed through untouched.
_METADATA_KEYS = frozenset({"cost", "annotations", "semantic", "concurrency"})


def tokenize(value: str) -> tuple[str, ...]:
    """Split a tool name or description the way a human types a query.

    ``browser_edit_feature_parameters`` and ``"edit feature parameters"`` must
    both match the query ``feature params``-style tokens, so underscores and
    hyphens become separators rather than part of a token.
    """
    return tuple(_TOKEN.findall(value.lower().replace("_", " ").replace("-", " ")))


def _schema_of(payload: Mapping[str, Any] | None) -> Mapping[str, Any]:
    if not payload:
        return {}
    schema = payload.get("inputSchema") or payload.get("input_schema") or {}
    return schema if isinstance(schema, Mapping) else {}


def confirmation_mode(
    payload: Mapping[str, Any] | None,
    *,
    overrides: Mapping[str, str] | None = None,
    name: str | None = None,
) -> str:
    """Classify a tool's confirmation gate from its own JSON Schema.

    The rules, in order, because the order is the semantics:

    1. no ``confirm_mutation`` property -> :data:`CONFIRMATION_NONE`;
    2. a ``dry_run`` property exists -> :data:`CONFIRMATION_NON_DRY_RUN`
       (the caller can preview, so only the real call needs a confirmation);
    3. ``confirm_mutation`` is schema-required -> :data:`CONFIRMATION_ALWAYS`;
    4. otherwise -> :data:`CONFIRMATION_RUNTIME_REQUIRED`.

    ``overrides`` exists for the genuinely irregular tool -- one whose gate is a
    budget override rather than a boolean -- and is keyed by tool name so the
    irregularity stays visible in one declaration instead of being smeared into
    the generic rule. The vocabulary is deliberately open: a project may name
    its own gate, and the layer must not decide which gate names are legal.
    """
    if overrides and name is not None and name in overrides:
        mode = overrides[name]
        if not isinstance(mode, str) or not mode.strip():
            raise SpecError(
                f"confirmation override for {name!r} must be a non-empty string"
            )
        return mode.strip()
    schema = _schema_of(payload)
    properties = schema.get("properties") or {}
    if not isinstance(properties, Mapping) or "confirm_mutation" not in properties:
        return CONFIRMATION_NONE
    if "dry_run" in properties:
        return CONFIRMATION_NON_DRY_RUN
    required = schema.get("required") or ()
    if isinstance(required, Iterable) and "confirm_mutation" in tuple(required):
        return CONFIRMATION_ALWAYS
    return CONFIRMATION_RUNTIME_REQUIRED


@dataclass(frozen=True, slots=True)
class ToolRecord:
    """A registered tool plus the facts a view needs to select it.

    ``payload`` is the exact object a client receives in ``tools/list``. When it
    is omitted the layer synthesizes a minimal object from ``name`` and
    ``description``; that is the right shape for a contract test or a project
    that has not written its schemas yet, and the wrong shape for a deployed
    server, which should always pass its real payload through.
    """

    name: str
    description: str = ""
    payload: Mapping[str, Any] | None = field(default=None, compare=False)
    category: str = "default"
    profiles: tuple[str, ...] = ()
    level: str | None = None
    keywords: tuple[str, ...] = ()
    network: str = "offline"
    mutating: bool = False
    dry_run: bool = False
    default_exposure: bool = True
    curated: bool = False
    absorbed: bool = False
    side_effects: tuple[str, ...] = ()
    requires: tuple[str, ...] = ()
    #: A gate the schema rule cannot express (an irregular tool whose
    #: confirmation is, say, a budget override). Kept on the record rather than
    #: in the policy so the irregularity lives with the tool it describes.
    confirmation_override: str | None = None
    cost: Mapping[str, Any] = field(default_factory=dict)
    concurrency: Mapping[str, Any] = field(default_factory=dict)
    search_tokens: frozenset[str] = field(default=frozenset(), compare=False)
    name_tokens: tuple[str, ...] = field(default=(), compare=False)

    def __post_init__(self) -> None:
        if not isinstance(self.name, str) or not self.name.strip():
            raise SpecError("a tool record needs a non-empty name")
        if self.level is not None and not isinstance(self.level, str):
            raise SpecError(f"{self.name}: level must be a string or None")
        if self.confirmation_override is not None and (
            not isinstance(self.confirmation_override, str)
            or not self.confirmation_override.strip()
        ):
            raise SpecError(
                f"{self.name}: confirmation_override must be a non-empty string or None"
            )
        if self.profiles and not all(isinstance(item, str) for item in self.profiles):
            raise SpecError(f"{self.name}: profiles must be strings")
        derived = frozenset(
            token
            for source in (
                self.name,
                " ".join(self.keywords),
                self.category,
                self.description,
            )
            for token in tokenize(source)
        )
        object.__setattr__(self, "search_tokens", derived)
        object.__setattr__(self, "name_tokens", tokenize(self.name))

    # -- derived views -----------------------------------------------------

    @property
    def input_schema(self) -> Mapping[str, Any]:
        return _schema_of(self.payload)

    @property
    def confirmation_mode(self) -> str:
        if self.confirmation_override is not None:
            return self.confirmation_override
        return confirmation_mode(self.payload, name=self.name)

    @property
    def confirmation_exposed(self) -> bool:
        properties = self.input_schema.get("properties") or {}
        return isinstance(properties, Mapping) and "confirm_mutation" in properties

    @property
    def confirmation_schema_required(self) -> bool:
        required = self.input_schema.get("required") or ()
        return isinstance(required, Iterable) and "confirm_mutation" in tuple(required)

    @property
    def requires_browser_session(self) -> bool:
        return bool((self.cost or {}).get("requires_browser_session", False))

    def advertised(self) -> dict[str, Any]:
        """The object this record puts on the wire.

        A record with a real payload returns it unchanged -- the layer must not
        be able to alter a schema it did not author. A record without one gets
        the minimal closed object, so an accidental extra argument is rejected
        at the schema layer instead of being ignored.
        """
        if self.payload is not None:
            return dict(self.payload)
        return {
            "name": self.name,
            "description": self.description,
            "inputSchema": {
                "type": "object",
                "properties": {},
                "additionalProperties": False,
            },
        }

    def summary(self, *, score: int | None = None, visible: bool | None = None) -> dict[str, Any]:
        """A bounded catalog line. Never the full schema; ``describe`` has that."""
        payload: dict[str, Any] = {
            "name": self.name,
            "description": compact(self.description),
            "category": self.category,
            "profiles": list(self.profiles),
            "semanticLevel": self.level,
            "network": self.network,
            "mutating": self.mutating,
            "dryRun": self.dry_run,
            "defaultExposure": self.default_exposure,
            "curated": self.curated,
            "compatibilityWrapper": self.absorbed,
            "confirmationExposed": self.confirmation_exposed,
            "confirmationSchemaRequired": self.confirmation_schema_required,
            "confirmationMode": self.confirmation_mode,
            "sideEffects": list(self.side_effects),
            "requiresBrowserSession": self.requires_browser_session,
            # Always true, and stated on every line rather than only when a view
            # was supplied: reachability by exact name is a property of the
            # layer, not of the connection the question came from.
            "reachableByExactName": True,
        }
        if score is not None:
            payload["score"] = score
        if visible is not None:
            payload["visibleInCurrentView"] = visible
        return payload

    def describe(self) -> dict[str, Any]:
        """The full entry: summary plus the exact schema a caller must satisfy."""
        entry = self.summary()
        entry["inputSchema"] = dict(self.input_schema) if self.input_schema else {
            "type": "object",
            "properties": {},
            "additionalProperties": False,
        }
        if self.cost:
            entry["cost"] = dict(self.cost)
        if self.concurrency:
            entry["concurrency"] = dict(self.concurrency)
        if self.requires:
            entry["requires"] = list(self.requires)
        return entry

    # -- construction ------------------------------------------------------

    @classmethod
    def from_payload(
        cls,
        payload: Mapping[str, Any],
        **metadata: Any,
    ) -> "ToolRecord":
        """Wrap a server's own tool dictionary, keeping it byte-identical.

        Metadata already inside the payload (``cost``, ``concurrency``) is read
        out unless the caller passes it explicitly, so a project that already
        annotates its tools does not repeat itself here.
        """
        if not isinstance(payload, Mapping) or not payload.get("name"):
            raise SpecError("a tool payload must be a mapping with a 'name'")
        name = str(payload["name"])
        description = str(metadata.pop("description", payload.get("description") or ""))
        for key in ("cost", "concurrency"):
            if key not in metadata and isinstance(payload.get(key), Mapping):
                metadata[key] = payload[key]
        return cls(name=name, description=description, payload=payload, **metadata)


def compact(value: str, limit: int = 180) -> str:
    """Whitespace-normalize and bound a description for a catalog line."""
    normalized = " ".join(str(value).split())
    if len(normalized) <= limit:
        return normalized
    return normalized[: limit - 3].rstrip() + "..."


def records_from_specs(specs: Iterable[Mapping[str, Any] | ToolRecord]) -> tuple[ToolRecord, ...]:
    """Build records from a mixed iterable of mappings and records.

    Order is preserved. Preserving it matters: the advertised order of a curated
    set is a routing decision, and a layer that silently sorted would turn
    "grouped by what the caller does next" back into registry order.
    """
    built: list[ToolRecord] = []
    seen: set[str] = set()
    for item in specs:
        record = item if isinstance(item, ToolRecord) else ToolRecord.from_payload(item)
        if record.name in seen:
            raise SpecError(f"duplicate registered tool name: {record.name}")
        seen.add(record.name)
        built.append(record)
    return tuple(built)
