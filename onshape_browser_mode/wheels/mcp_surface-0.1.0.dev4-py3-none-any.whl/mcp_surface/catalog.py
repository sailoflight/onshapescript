"""Bounded lookup over the registry: index, search, describe.

A compressed surface forces callers to look tools up by name, so the *lookup*
becomes part of the product and has to be priced like one. The measured rule
from the source project is that the answer's size dominates its depth: one
unbounded listing (an outline of every section, a full function dump) cost two
thirds of the entire advertised surface per read and, being read early in a
session, rented for every remaining step. So every answer here is **compact by
default with an explicit opt-in**, and every list is capped by a named limit
rather than truncated silently.

The three actions and the layer they belong to:

``index``
    Layer 1, cheapest: one line per category, or a bounded page of names for one
    category. It answers "which names exist" without answering "what does this
    name do".
``search``
    Layer 1-2: scored matches. A result carries the fields needed to decide
    whether to call it, not the schema.
``describe``
    Layer 2, the only expensive answer: the exact input schema a call must
    satisfy. Reached only when the search line cannot identify the name.

Determinism is a contract, not a nicety. An answer that depends on
``PYTHONHASHSEED`` cannot be diffed between two runs, cannot be snapshotted in a
test, and cannot be trusted by a caller who cached it -- so ranking is on
declared values with an explicit tie-break, and equality across hash seeds is
covered by a test that has to spawn separate processes to mean anything.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from typing import Any

from .errors import SurfaceRequestError, UnknownToolName
from .model import ToolRecord, tokenize
from .views import Surface, ToolViewState

#: Caps ship with their reasoning: twelve matches is already a page nobody reads
#: to the end, and the index is deliberately small because it is layer 1.
MAX_SEARCH_RESULTS = 12
DEFAULT_SEARCH_RESULTS = 8
MAX_INDEX_RESULTS = 40
DEFAULT_INDEX_RESULTS = 40
#: How many names an index line shows as examples. Enough to recognise the
#: category, not enough to read the registry.
INDEX_EXAMPLES = 3

#: Token weights. Name beats keyword beats category beats description, because
#: that is the order in which a match predicts the tool the caller wants. The
#: numbers are declared so a project can argue with them in one place.
WEIGHT_NAME = 10
WEIGHT_KEYWORD = 6
WEIGHT_CATEGORY = 3
WEIGHT_DESCRIPTION = 2
WEIGHT_EXACT_NAME = 1000
WEIGHT_SUBSTRING = 5


class ToolCatalog:
    """Registry lookup for one :class:`Surface`.

    The catalog never advertises anything: it answers questions. Whether an
    answer names a tool that is currently listed is reported as
    ``visibleInCurrentView`` and never used to filter, because a catalog that
    hid hidden names would make the compression lossy.
    """

    def __init__(
        self,
        surface: Surface,
        *,
        max_search_results: int = MAX_SEARCH_RESULTS,
        default_search_results: int = DEFAULT_SEARCH_RESULTS,
        max_index_results: int = MAX_INDEX_RESULTS,
        default_index_results: int = DEFAULT_INDEX_RESULTS,
    ) -> None:
        if default_search_results > max_search_results:
            raise SurfaceRequestError(
                "default_search_results cannot exceed max_search_results"
            )
        if default_index_results > max_index_results:
            raise SurfaceRequestError(
                "default_index_results cannot exceed max_index_results"
            )
        self.surface = surface
        self.max_search_results = max_search_results
        self.default_search_results = default_search_results
        self.max_index_results = max_index_results
        self.default_index_results = default_index_results

    # -- shared helpers ----------------------------------------------------

    def fingerprint(self) -> str:
        return self.surface.fingerprint()

    def status(self) -> dict[str, Any]:
        """A cheap health answer: sizes and identity, not contents."""
        categories = self.surface.categories()
        return {
            "action": "status",
            "registryCount": len(self.surface.records),
            "categoryCount": len(categories),
            "categories": [
                {
                    "name": category,
                    "purpose": self.surface.category_purpose(category),
                    "tools": sum(
                        1
                        for record in self.surface.records
                        if record.category == category
                    ),
                }
                for category in categories
            ],
            "profiles": list(self.surface.policy.profile_names()),
            "levels": list(self.surface.policy.levels),
            "fingerprint": self.fingerprint(),
            "fingerprintNote": (
                "Recomputed from the declared registry; any description or schema "
                "key change moves it, so read it here instead of storing one."
            ),
            "searchAvailable": True,
            "describeAvailable": True,
        }

    def _limit(self, limit: int | None, *, default: int, maximum: int) -> int:
        if limit is None:
            return default
        if not isinstance(limit, int) or isinstance(limit, bool):
            raise SurfaceRequestError("limit must be an integer")
        if limit < 1:
            raise SurfaceRequestError("limit must be at least 1")
        return min(limit, maximum)

    def _visible_names(self, view: ToolViewState | Iterable[str] | None) -> set[str] | None:
        if view is None:
            return None
        if isinstance(view, ToolViewState):
            return set(view.listed_names())
        return {str(name) for name in view}

    def _rank_levels(self) -> tuple[str | None, ...]:
        policy = self.surface.policy
        if policy.rank_levels:
            return tuple(policy.rank_levels)
        return tuple(policy.levels) + (None,)

    def _rank_key(self, record: ToolRecord) -> tuple[int, str]:
        order = self._rank_levels()
        try:
            index = order.index(record.level)
        except ValueError:
            index = len(order)
        return index, record.name

    def _score(self, record: ToolRecord, tokens: tuple[str, ...], normalized: str) -> int:
        if not tokens:
            return 0
        name_tokens = set(record.name_tokens)
        keyword_tokens = set(tokenize(" ".join(record.keywords)))
        category_tokens = set(tokenize(record.category))
        description_tokens = (
            set(record.search_tokens) - name_tokens - keyword_tokens - category_tokens
        )
        score = 0
        for token in tokens:
            if token in name_tokens:
                score += WEIGHT_NAME
            elif token in keyword_tokens:
                score += WEIGHT_KEYWORD
            elif token in category_tokens:
                score += WEIGHT_CATEGORY
            elif token in description_tokens:
                score += WEIGHT_DESCRIPTION
        if score == 0:
            return 0
        if " ".join(record.name_tokens) == normalized:
            score += WEIGHT_EXACT_NAME
        elif normalized and normalized in " ".join(record.name_tokens):
            score += WEIGHT_SUBSTRING
        return score

    # -- actions -----------------------------------------------------------

    def index(
        self,
        *,
        category: str | None = None,
        limit: int | None = None,
        view: ToolViewState | Iterable[str] | None = None,
    ) -> dict[str, Any]:
        """Layer 1. One line per category, or a bounded page of one category."""
        visible = self._visible_names(view)
        if category is None:
            lines: list[dict[str, Any]] = []
            for name in self.surface.categories():
                members = sorted(
                    (record for record in self.surface.records if record.category == name),
                    key=self._rank_key,
                )
                lines.append(
                    {
                        "name": name,
                        "purpose": self.surface.category_purpose(name),
                        "tools": len(members),
                        "levels": sorted(
                            {record.level for record in members if record.level},
                            key=self._level_sort_key,
                        ),
                        "examples": [record.name for record in members[:INDEX_EXAMPLES]],
                    }
                )
            return {
                "action": "index",
                "registryCount": len(self.surface.records),
                "categories": lines,
                "next": (
                    "Call index with a category for a bounded name page, or search "
                    "with a query; describe is the only answer that carries a schema."
                ),
            }
        if category not in self.surface.categories():
            raise SurfaceRequestError(
                f"unknown category {category!r}; known: "
                f"{', '.join(self.surface.categories())}"
            )
        capped = self._limit(limit, default=self.default_index_results, maximum=self.max_index_results)
        members = sorted(
            (record for record in self.surface.records if record.category == category),
            key=self._rank_key,
        )
        page = members[:capped]
        return {
            "action": "index",
            "category": category,
            "purpose": self.surface.category_purpose(category),
            "total": len(members),
            "limit": capped,
            "truncated": len(page) < len(members),
            "tools": [
                {
                    "name": record.name,
                    "semanticLevel": record.level,
                    "mutating": record.mutating,
                    "visibleInCurrentView": (
                        None if visible is None else record.name in visible
                    ),
                }
                for record in page
            ],
        }

    def search(
        self,
        query: str,
        *,
        limit: int | None = None,
        view: ToolViewState | Iterable[str] | None = None,
        category: str | None = None,
    ) -> dict[str, Any]:
        """Layer 1-2. Scored matches, bounded, with the fields needed to choose."""
        if not isinstance(query, str):
            raise SurfaceRequestError("query must be a string")
        capped = self._limit(
            limit, default=self.default_search_results, maximum=self.max_search_results
        )
        if category is not None and category not in self.surface.categories():
            raise SurfaceRequestError(
                f"unknown category {category!r}; known: "
                f"{', '.join(self.surface.categories())}"
            )
        visible = self._visible_names(view)
        tokens = tokenize(query)
        normalized = " ".join(tokens)
        candidates = (
            self.surface.records
            if category is None
            else tuple(
                record for record in self.surface.records if record.category == category
            )
        )
        scored = [
            (self._score(record, tokens, normalized), record) for record in candidates
        ]
        if tokens:
            scored = [item for item in scored if item[0] > 0]
        scored.sort(key=lambda item: (-item[0], self._rank_key(item[1])))
        page = scored[:capped]
        return {
            "action": "search",
            "query": query,
            "category": category,
            "count": len(page),
            "matched": len(scored),
            "limit": capped,
            "truncated": len(page) < len(scored),
            "results": [
                record.summary(
                    score=score,
                    visible=None if visible is None else record.name in visible,
                )
                for score, record in page
            ],
            "note": (
                "A hidden name is still callable by exact name; describe it for the "
                "schema a call must satisfy."
            ),
        }

    def describe(
        self,
        name: str,
        *,
        view: ToolViewState | Iterable[str] | None = None,
    ) -> dict[str, Any]:
        """Layer 2. The exact schema, which is why this is the expensive answer."""
        if not isinstance(name, str) or not name.strip():
            raise SurfaceRequestError("name must be a non-empty string")
        try:
            record = self.surface.record(name)
        except UnknownToolName:
            suggestions = [
                record.name
                for _score, record in sorted(
                    (
                        (self._score(item, tokenize(name), " ".join(tokenize(name))), item)
                        for item in self.surface.records
                    ),
                    key=lambda item: (-item[0], self._rank_key(item[1])),
                )[:3]
                if _score > 0
            ]
            raise UnknownToolName(
                f"unknown tool name: {name!r}"
                + (f"; did you mean: {', '.join(suggestions)}" if suggestions else "")
            ) from None
        visible = self._visible_names(view)
        entry = record.describe()
        entry["action"] = "describe"
        entry["visibleInCurrentView"] = None if visible is None else name in visible
        return entry

    # -- dispatch ----------------------------------------------------------

    def dispatch(
        self,
        arguments: Mapping[str, Any] | None = None,
        *,
        view: ToolViewState | Iterable[str] | None = None,
    ) -> dict[str, Any]:
        """Route one ``mcp_tool_catalog`` call. The single reusable handler.

        Keeping the routing here is most of the point of the library: a project
        that re-implements this per server gets the argument names, the limits
        and the error shape slightly different from the catalog it advertises.
        """
        args = dict(arguments or {})
        action = args.get("action", "index")
        if action == "index":
            return self.index(
                category=_optional_str(args, "category"),
                limit=_optional_int(args, "limit"),
                view=view,
            )
        if action == "search":
            query = args.get("query")
            if not isinstance(query, str) or not query.strip():
                raise SurfaceRequestError("search requires a non-empty 'query'")
            return self.search(
                query,
                limit=_optional_int(args, "limit"),
                view=view,
                category=_optional_str(args, "category"),
            )
        if action == "describe":
            name = args.get("name")
            if not isinstance(name, str) or not name.strip():
                raise SurfaceRequestError("describe requires a non-empty 'name'")
            return self.describe(name, view=view)
        if action == "status":
            return {**self.status(), "visibleInCurrentView": None}
        raise SurfaceRequestError(
            "action must be one of: index, search, describe, status"
        )

    def _level_sort_key(self, level: str) -> tuple[int, str]:
        order = self.surface.policy.levels
        return (order.index(level) if level in order else len(order), level)


def _optional_str(args: Mapping[str, Any], key: str) -> str | None:
    value = args.get(key)
    if value is None:
        return None
    if not isinstance(value, str):
        raise SurfaceRequestError(f"{key} must be a string")
    return value


def _optional_int(args: Mapping[str, Any], key: str) -> int | None:
    value = args.get(key)
    if value is None:
        return None
    if not isinstance(value, int) or isinstance(value, bool):
        raise SurfaceRequestError(f"{key} must be an integer")
    return value
