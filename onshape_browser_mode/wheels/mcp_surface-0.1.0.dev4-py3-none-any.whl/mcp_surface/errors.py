"""Failure types for the tool-surface layer.

The layer has exactly two kinds of failure and they want different reactions, so
they are different classes rather than one error with a message prefix:

``SpecError``
    The caller's *declaration* is wrong -- a curated name that is not
    registered, two profiles with one name, a level outside the declared set.
    This is a programming or configuration fault at build time; nothing about a
    session can fix it, and every method that can detect it detects it in the
    constructor so it cannot hide until the one session that routes through the
    broken name.

``SurfaceRequestError``
    The *call* is wrong -- ``mcp_tool_view action=expand`` on a fixed view, an
    ``action`` outside the declared set, a name that is not in the registry.
    The caller can correct this and retry, and the message says what would have
    been valid.

Both derive from :class:`McpSurfaceError` so an embedding server can map the
whole layer to one client-visible error without also catching its own bugs.
"""

from __future__ import annotations


class McpSurfaceError(Exception):
    """Base class for every failure this layer raises."""


class SpecError(McpSurfaceError):
    """A tool-surface declaration is internally inconsistent."""


class SurfaceRequestError(McpSurfaceError):
    """A request against the surface is invalid; the caller can fix and retry."""


class UnknownToolName(SurfaceRequestError):
    """The name is not in the registry.

    Distinct from "hidden": a hidden name resolves here without error, because
    hiding a tool is context routing and never removes authority. Only a name
    that was never registered raises this.
    """


class ViewSwitchUnavailable(SurfaceRequestError):
    """``expand``/``collapse``/``set`` was asked of a mode that has no state.

    Only ``dynamic`` switches. In every other mode the advertised set is a pure
    function of the mode and the policy, so accepting a switch would advertise a
    state the next ``status`` could not report.
    """
