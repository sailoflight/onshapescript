# mcp_surface 适配手册

这份手册随 wheel 携带，可通过 `importlib.resources.files("mcp_surface")` 读取
`docs/ADAPTATION_GUIDE.md`。它讲**怎么接**和**为什么这么接**；API 的权威是源码与
`tests/`，不在这里重复维护第二份声明表。

---

## 1. 这一层解决什么

MCP 的 `tools/list` 是**租金**：它每个 step 都被重新读一遍，所以注册表越大，
每一个会话的每一轮都在为它付钱——哪怕这个会话根本不用那些工具。

被实测的另一个不对称是：**一次查找回合**（模型为了决定怎么用答案而重读整个前缀）
比**多列一个 schema** 贵一个数量级。这两条合起来否定了两种极端做法：

- 「全列出来」：不用的工具也在收租；
- 「几乎不列」：常用工具每次多付一个回合。

所以这一层提供的不是折中，而是**可算的选择**：模式 + 名单裁剪 + 一条按名字取用的门，
并且把每个决定的成本模型一起给你，让你能自己算账。

### 不做什么

- **不是 MCP 服务器**：不碰 transport、不实现会话、不 import 任何 MCP SDK。
- **不是第二份注册表**：工具定义和 handler 仍然归你；这一层不改写它没有作者权的 schema。
- **不改权限**：隐藏只是**上下文路由**。真正服务端里，未列出的已知名字仍然可以按名字调用，
  确认、额度、dry-run、验收门一个都不少。这一层把这个义务写进 `status()`
  （`authorityChanged: false`、`hiddenNamesStillCallable: true`），并让 `Surface.record()`
  成为「无视图过滤地按名字解析」的参考实现。

---

## 2. 五分钟接入

```python
from mcp_surface import ProfileRule, SurfacePolicy, bootstrap

policy = SurfacePolicy(
    profiles=(
        ProfileRule("browser", "浏览器腿。", prefixes=("browser_",)),
        ProfileRule("docs", "离线参考。", prefixes=("docs_", "fs_")),
    ),
    curated=(                       # gateway 会列出的代表，按声明顺序
        "browser_session",
        "browser_insert_custom_feature",
        "docs_search",
        "docs_section",
    ),
    absorbed=frozenset({"fs_list_modules"}),   # 兼容包装名，只在完整视图出现
    always_visible=frozenset({"browser_session"}),
    category_purposes={"control": "发现与视图状态。", "browser": "浏览器腿。"},
    chains=(("docs_search", "docs_section"),),  # 规定了的两步查找
    rank_levels=("L5", "L4", "L2", "L6", None, "L3", "L1"),
)

surface, catalog, state = bootstrap(my_tool_payloads, policy, mode="gateway")

# tools/list 就是这一串：
advertised = state.advertised()

# 目录调用：
catalog.dispatch({"action": "search", "query": "render"})
```

`bootstrap` 会**在启动时校验**：把声明错误变成启动崩溃，而不是某个会话里莫名少一个工具。

模式可以从环境取：`mode=None` 时按 `显式参数 → MCP_TOOL_EXPOSURE → gateway` 取值
（前缀可用 `env_prefix` 改）。文件配置留在业务侧——配置文件放哪儿是部署事实，不是库事实。

---

## 3. 记录：`ToolRecord`

你可以直接传原始工具字典（`Surface` 会包成 record），也可以传 `ToolRecord` 补元数据。
`payload` 原样进入 `tools/list`，这一层**不会**改写它。

| 字段 | 作用 | 默认 |
|---|---|---|
| `payload` | 客户端看到的原始工具对象 | 省略时合成一个闭合空 schema |
| `category` | 目录分组；`category_purposes` 的键 | `default` |
| `level` | 语义档位 `L1..L6`（词汇表由 `policy.levels` 定） | `None` |
| `keywords` | 搜索加权词 | `()` |
| `network` | `offline`/`browser`/`live` 之类；是否受约束由 `policy.networks` 决定 | `offline` |
| `mutating` / `dry_run` / `side_effects` | 供调用方判断代价 | `False` / `()` |
| `default_exposure` | `False` = 普通视图不列，但仍可按名字调用 | `True` |
| `absorbed` | 被合并吸收的兼容包装名，只在 `all` 视图出现 | `False` |
| `confirmation_override` | schema 规则表达不了的确认形态（如预算覆盖） | `None` |
| `cost` / `concurrency` | 透传元数据；`cost.requires_browser_session` 会被读出 | `{}` |

**派生而不是重复声明**的两件事：

- `search_tokens` 从名字、关键词、类别、描述一次性切好——搜索不会和实际读到的文本脱节；
- `confirmation_mode` 从工具**自己的 JSON Schema** 读出：无 `confirm_mutation` → `none`；
  有 `dry_run` → `non_dry_run`；`confirm_mutation` 在 `required` 里 → `always`；
  否则 → `runtime_required`。改 schema 就会改目录里的报告，不需要同步第三份清单。

> `none` 不等于「安全」，只等于「没有这个门」。一个会写盘的工具有没有门，是目录要**暴露**
> 的事实，不是要藏起来的事实。

---

## 4. 策略：`SurfacePolicy`

| 字段 | 含义 |
|---|---|
| `profiles` | 命名视图：`ProfileRule(name, description, prefixes=, names=, predicate=)` |
| `control_names` | 控件工具名，**按 catalog / view / invoke 的位置语义**，最多三个，至少一个 |
| `curated` | gateway 列出的代表，**顺序即路由顺序**，不排序 |
| `absorbed` | 只在完整视图出现的兼容名 |
| `always_visible` | 在每个包含其类别的视图里都出现，**且不受档位过滤影响** |
| `levels` | 档位词汇表 |
| `rank_levels` | 搜索并列时的排序偏好；`None` 是合法成员，表示「没声明档位」 |
| `category_purposes` | 每个类别一句话，让调用方不看工具就能路由 |
| `chains` | 规定了的两步（或更多步）查找，用于断链检查 |
| `networks` | 允许的 `network` 值；空 = 不约束 |
| `default_profile` | `default` 之外可另指定启动档 |
| `default_expanded_view` | 冷启动 `expand` 打开哪个显示集；默认 `gateway`。`curated` 为空的项目要设成 `static`，否则「展开」打开的集合与折叠时一模一样 |
| `gateway_reason` | 会出现在 `status()` 里，让运维看到取舍而不是猜 |

保留档名 `default`（有界常规视图）与 `all`（完整注册表）不可重声明。

---

## 5. 五种模式

| 模式 | 列出的集合 | 有折叠状态 |
|---|---|---|
| `static` | 完整注册表 | 否 |
| `semantic` | 有界常规视图（无视启动档） | 否 |
| `profile` | 命名档视图 | 否 |
| `gateway` | 控件 + 代表名单（默认） | 否 |
| `dynamic` | 冷启动只列控件；`expand` 后是某个显示集 | **是** |

`dynamic` 的 `expand` 默认打开 `policy.default_expanded_view`，也可以按次指定 `expanded_view`（`static`/`semantic`/`gateway`/`profile`）、
`profile`、`semantic_levels`；`set` 是历史别名（省略档位列表表示**清空过滤**，而不是保持）。
`collapse`/`reset` 是纯内存状态，不写任何地方。

状态是**连接级**的，不是会话级的：stdio 服务端只看得到连接和上面的消息，看不到客户端在
一条连接上复用的多个会话。`status()` 明写 `scope: "connection"`，不假装有它看不见的隔离。

---

## 6. 接三个控件工具

```python
definitions = control_tool_definitions(surface)   # 三个工具对象，schema 从策略派生

def on_call(name, arguments):
    return dispatch_control(
        name, arguments,
        surface=surface, catalog=catalog, state=state,
        invoke=my_registry_dispatch,   # 传进来就会真的转发到同一个 handler
    )
```

`dispatch_control` 是纯路由，不做协议。`invoke` 这一路的意义在于：**「隐藏的名字仍可调用」
是服务端的性质，不是每个客户端的性质**。实测过一个真实客户端，在名字离开 `tools/list`
之后直接回 `unknown tool`，而服务端本来乐意派发。所以压缩过的表面必须带一条按名字的门，
而且要在**每一种模式**里都列出来——一条通往「调不到的名字」的查找链，比不压缩更糟。

`state.apply()` 返回 `(payload, changed)`；只有 `changed` 为真时才发
`notifications/tools/list_changed`，否则每个 no-op 都会吵醒连接上的所有会话。

---

## 7. 不变量与自检

```python
Surface(...).problems()                  # 声明错误，一次全报
Surface(...).audit()                     # 计数、指纹、gateway 断链
audit_surface(surface)                   # 上面这些 + 成本 + curated 条目算账
surface.chain_violations(state.listed_names())
```

**断链**是最值得盯的一条：一条规定的两步查找，只列第一步等于让调用方付第一步的租金
**再**多付一个回合——比两端都列或都不列都差。把它放进你自己的测试里（本库的
`tests/test_views.py` 就是这么用的）。

**指纹**：`surface.fingerprint()` / `catalog.status()["fingerprint"]`。任何描述或 schema
键变化都会改变它。所以**不要存一份指纹**，需要时读；存下来的那份，第一次有人忘记更新
就是错的。

**确定性**：同一模式 + 同一档 + 同一过滤 → 逐字节相同的集合，与 `PYTHONHASHSEED` 无关。
库里有跨三个种子的子进程测试守着这条，因为一个进程内部证明不了它自己运行时的顺序。

---

## 8. 成本模型怎么用

```python
from mcp_surface import SessionModel, view_report, curation_review, break_even_expected_use

model = SessionModel(prefix_tokens=8000, growth_tokens=600, steps=30)
view_report(surface, model=model)        # 各视图的 wire 尺寸 + 用到的模型
curation_review(surface, model=model)    # 逐条：租金、一次查找的代价、盈亏平衡点
```

模型写在 `measure.py` 的模块文档里，全部是**参数不是测量**：前缀属于客户端，服务端看不见。
`breakEvenExpectedUse` = 「列出来划算」所需要的会话占比；超过 1.0 的条目只有作为规定链条的
一环才值得列。token 数是按字符比的**估计**，本层不依赖 tokenizer，也不声称做过
tokenizer 测量。

---

## 9. 验证清单

```bash
cd mcp_surface
PYTHONPATH=src PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -v
```

覆盖：视图选择语义、折叠状态机与 `changed` 语义、隐藏名仍可解析、目录边界与
`index/search/describe`、三个种子的逐字节确定性、声明错误逐条、成本模型算术与排序、
导入无副作用（独立进程、洁净环境）。

---

## 10. 边界

- 不安装依赖、不注册 MCP、不写业务配置；导入无副作用（不读环境、不开文件、不拉 SDK）。
- 不代理 handler：`dispatch_control` 返回转发指令或调用你给的 `invoke`，确认/额度/验收门
  原样生效。
- 不判断业务成功、不定义路径围栏、不做超时与中断——那些是服务端的事。
- 连接级状态不隔离多会话；同步语义，不引入线程或循环假设。
- `category_purposes` 只描述类别，不描述工具；工具的一句 `when` 由业务自己写进 `description`。
