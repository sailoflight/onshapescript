"""The cost model, so a curation decision is arithmetic instead of taste.

Compression only has a defensible answer if both sides of the trade are
measured in the same unit. The unit here is *tokens re-read*, and the model is
deliberately simple and stated in full, because an unstated model is how a
"2.5x cheaper" claim becomes something nobody can check:

::

    input_tokens(session) ~= sum over steps of (P0 + step*g + S + artifacts so far)

* ``P0`` the fixed prefix (system prompt, client scaffolding) -- the client owns
  it and the server cannot see it, so it is a parameter with a documented
  default, never a measurement;
* ``g`` growth per step;
* ``S`` the advertised tool surface, re-read at **every** step;
* artifacts (a catalog answer, a describe) rent from the step they are read
  until the end, because a stateless protocol keeps them in the transcript.

Two consequences the code exists to make checkable: a *surface* is paid every
step, while a *lookup round* is paid once and then costs the whole prefix to
re-read. That asymmetry is why neither "advertise everything" nor "advertise
almost nothing" is the right default, and why the numbers below are reported
with their assumptions attached.

Token counts are ESTIMATES at the documented characters-per-token ratio. There
is no tokenizer dependency here on purpose: a library must not claim a
tokenizer measurement it did not take.
"""

from __future__ import annotations

import json
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from typing import Any

from .model import ToolRecord
from .views import (
    ALL_PROFILE,
    DEFAULT_PROFILE,
    MODE_GATEWAY,
    MODE_STATIC,
    Surface,
    ToolViewState,
)

#: The documented defaults. The source project's research used these figures;
#: they are parameters, not findings, and every report echoes them back.
DEFAULT_CHARS_PER_TOKEN = 4.0
DEFAULT_PREFIX_TOKENS = 8_000
DEFAULT_GROWTH_TOKENS = 600
DEFAULT_STEPS = 30


@dataclass(frozen=True, slots=True)
class SessionModel:
    """The session shape all cost figures are quoted against."""

    prefix_tokens: int = DEFAULT_PREFIX_TOKENS
    growth_tokens: int = DEFAULT_GROWTH_TOKENS
    steps: int = DEFAULT_STEPS
    chars_per_token: float = DEFAULT_CHARS_PER_TOKEN

    def as_dict(self) -> dict[str, Any]:
        return {
            "prefixTokens": self.prefix_tokens,
            "growthTokensPerStep": self.growth_tokens,
            "steps": self.steps,
            "charsPerToken": self.chars_per_token,
            "note": (
                "Parameters, not measurements: the prefix belongs to the client. "
                "Comparisons hold as ratios of one session shape."
            ),
        }


@dataclass(frozen=True, slots=True)
class SurfaceSize:
    """One advertised set, measured as the compact JSON that crosses the wire."""

    label: str
    tools: int
    chars: int
    est_tokens: int

    def as_dict(self) -> dict[str, Any]:
        return {
            "label": self.label,
            "tools": self.tools,
            "chars": self.chars,
            "estTokens": self.est_tokens,
        }


def compact_json(value: Any) -> str:
    """The wire form: no indentation, stable key order."""
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def estimate_tokens(text: str, chars_per_token: float = DEFAULT_CHARS_PER_TOKEN) -> int:
    if chars_per_token <= 0:
        raise ValueError("chars_per_token must be positive")
    return int(len(text) / chars_per_token)


def size_of_records(
    records: Iterable[ToolRecord],
    *,
    label: str,
    chars_per_token: float = DEFAULT_CHARS_PER_TOKEN,
) -> SurfaceSize:
    tools = tuple(records)
    chars = len(compact_json([record.advertised() for record in tools]))
    return SurfaceSize(
        label=label,
        tools=len(tools),
        chars=chars,
        est_tokens=estimate_tokens("x" * chars, chars_per_token),
    )


def surface_size(
    surface: Surface,
    *,
    label: str = "static",
    chars_per_token: float = DEFAULT_CHARS_PER_TOKEN,
) -> SurfaceSize:
    """Size one named view of a surface without building a connection."""
    if label == MODE_STATIC:
        records = surface.records
    elif label == MODE_GATEWAY:
        records = surface.gateway_records()
    elif label == ALL_PROFILE or label == "all":
        records = surface.select(profile=ALL_PROFILE)
    else:
        records = surface.select(profile=label)
    return size_of_records(records, label=label, chars_per_token=chars_per_token)


def view_report(
    surface: Surface,
    *,
    model: SessionModel | None = None,
    extra_labels: Iterable[str] = (),
) -> dict[str, Any]:
    """Every comparable view, measured, plus the model they are quoted against.

    Returning the model with the numbers is the point: a caller that forwards a
    figure without the assumptions is how an estimate becomes a promise.
    """
    resolved = model or SessionModel()
    labels = [MODE_GATEWAY, DEFAULT_PROFILE, MODE_STATIC]
    labels.extend(surface.policy.profile_names())
    labels.extend(str(label) for label in extra_labels)
    seen: dict[str, None] = {}
    sizes: list[SurfaceSize] = []
    for label in labels:
        if label in seen:
            continue
        seen.setdefault(label, None)
        if not label:
            continue
        try:
            sizes.append(
                surface_size(
                    surface, label=label, chars_per_token=resolved.chars_per_token
                )
            )
        except Exception:  # an unknown label is simply not a view
            continue
    sizes.sort(key=lambda item: (item.est_tokens, item.label))
    return {
        "model": resolved.as_dict(),
        "surfaces": [size.as_dict() for size in sizes],
        "cheapest": sizes[0].as_dict() if sizes else None,
        "mostExpensive": sizes[-1].as_dict() if sizes else None,
    }


# -- the cost model --------------------------------------------------------


def session_cost(
    model: SessionModel,
    *,
    surface_tokens: int = 0,
    artifact_tokens: int = 0,
    artifact_read_step: int = 1,
) -> int:
    """Total re-read cost of one session under the model above."""
    if model.steps < 1:
        raise ValueError("steps must be at least 1")
    prefix = model.steps * model.prefix_tokens
    growth = model.growth_tokens * model.steps * (model.steps + 1) // 2
    surface = surface_tokens * model.steps
    step = max(1, min(artifact_read_step, model.steps))
    artifact = artifact_tokens * (model.steps - step + 1)
    return prefix + growth + surface + artifact


def lookup_round_cost(
    model: SessionModel,
    *,
    artifacts: int = 0,
    surface_tokens: int = 0,
) -> int:
    """One extra round: the prefix it re-reads, plus the answer's own rent.

    This is the number that makes hiding a *regularly used* tool the wrong
    default. It is not a token count of the answer; the answer is the small
    part.
    """
    prefix = model.prefix_tokens + model.growth_tokens * model.steps + surface_tokens
    return prefix + artifacts


def entry_rent(entry_tokens: int, model: SessionModel) -> int:
    """What one advertised entry costs over the whole session."""
    return entry_tokens * model.steps


def break_even_expected_use(
    entry_tokens: int,
    model: SessionModel,
    *,
    round_cost: int,
) -> float:
    """The fraction of sessions an entry must be used in to pay for itself.

    Listing costs ``entry_tokens * steps`` no matter what; not listing costs
    ``p * round_cost``. Break-even is where those are equal. Below it, the entry
    belongs behind the per-name door.
    """
    if round_cost <= 0:
        raise ValueError("round_cost must be positive")
    return entry_rent(entry_tokens, model) / round_cost


def widening_ratio(added_tokens: int, model: SessionModel, *, round_cost: int) -> float:
    """How many per-name lookups a permanently wider surface is worth."""
    if round_cost <= 0:
        raise ValueError("round_cost must be positive")
    return added_tokens * model.steps / round_cost


def curation_review(
    surface: Surface,
    *,
    model: SessionModel | None = None,
    round_tokens: int | None = None,
) -> dict[str, Any]:
    """Per-entry arithmetic behind the curated set.

    Reported for every `default_visible` tool, so the set can be argued with
    entry by entry instead of as a whole. A curated entry whose break-even
    exceeds 1.0 is not automatically wrong -- the second leg of a prescribed
    chain is worth listing even at a loss, which is exactly what
    :meth:`Surface.chain_violations` guards -- so this reports rather than decides.
    """
    resolved = model or SessionModel()
    advertised = tuple(record.advertised() for record in surface.gateway_records())
    surface_tokens = estimate_tokens(
        compact_json(advertised), resolved.chars_per_token
    )
    round_cost = round_tokens or lookup_round_cost(
        resolved, surface_tokens=surface_tokens
    )
    curated = set(surface.policy.curated)
    rows: list[dict[str, Any]] = []
    for record in surface.records:
        size = size_of_records(
            (record,), label=record.name, chars_per_token=resolved.chars_per_token
        )
        rows.append(
            {
                "name": record.name,
                "curated": record.name in curated,
                "entryTokens": size.est_tokens,
                "rentOverSession": entry_rent(size.est_tokens, resolved),
                "breakEvenExpectedUse": round(
                    break_even_expected_use(
                        size.est_tokens, resolved, round_cost=round_cost
                    ),
                    3,
                ),
                "costOfOneLookupInstead": round_cost,
            }
        )
    rows.sort(key=lambda row: (-row["breakEvenExpectedUse"], row["name"]))
    return {
        "model": resolved.as_dict(),
        "gatewaySurfaceTokens": surface_tokens,
        "lookupRoundTokens": round_cost,
        "entries": rows,
        "note": (
            "breakEvenExpectedUse is the fraction of sessions the entry must be "
            "used in for listing it to beat one lookup. Above 1.0 it only pays "
            "as part of a prescribed chain."
        ),
    }


# -- invariants ------------------------------------------------------------


def chain_violations(
    surface: Surface,
    advertised: Iterable[str] | ToolViewState,
) -> tuple[dict[str, Any], ...]:
    """Prescribed lookups the advertised set cuts in half.

    A convenience over :meth:`Surface.chain_violations` that accepts a view
    state, because that is what a test has in hand. Advertising the first step
    of a two-step lookup without the second makes the caller pay the first
    step's rent *and* a round -- strictly worse than either end of the trade.
    """
    if isinstance(advertised, ToolViewState):
        names: Iterable[str] = advertised.listed_names()
    else:
        names = advertised
    return surface.chain_violations(names)


def audit_surface(surface: Surface, *, model: SessionModel | None = None) -> dict[str, Any]:
    """One call that answers "is this surface defensible", with its own report."""
    resolved = model or SessionModel()
    gateway = surface.gateway_records()
    gateway_size = size_of_records(
        gateway, label=MODE_GATEWAY, chars_per_token=resolved.chars_per_token
    )
    default_state = surface.view(mode=MODE_GATEWAY)
    return {
        "fingerprint": surface.fingerprint(),
        "model": resolved.as_dict(),
        "counts": {
            "registry": len(surface.records),
            "gateway": len(gateway),
            "defaultVisible": len(surface.select(profile=DEFAULT_PROFILE)),
            "complete": len(surface.select(profile=ALL_PROFILE)),
            "hiddenOutsideComplete": len(surface.records)
            - len(surface.select(profile=ALL_PROFILE)),
        },
        "gateway": gateway_size.as_dict(),
        "chainViolations": list(chain_violations(surface, default_state)),
        "categories": list(surface.categories()),
        "curation": [
            row
            for row in curation_review(surface, model=resolved)["entries"]
            if row["curated"]
        ],
    }
