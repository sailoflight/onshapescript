"""Configuration data only: no browser imports, file reads or discovery."""
from __future__ import annotations

from collections.abc import Mapping
from copy import deepcopy
from dataclasses import dataclass, field
from pathlib import Path
from types import MappingProxyType
from typing import Any
from urllib.parse import urlsplit
import re


def _freeze(value: Any) -> Any:
    if isinstance(value, Mapping):
        return MappingProxyType({key: _freeze(item) for key, item in value.items()})
    if isinstance(value, (tuple, list)):
        return tuple(_freeze(item) for item in value)
    return deepcopy(value)


def _thaw(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {key: _thaw(item) for key, item in value.items()}
    if isinstance(value, tuple):
        return [_thaw(item) for item in value]
    return deepcopy(value)


@dataclass(frozen=True, slots=True)
class PageRule:
    """Prefer a live page by exact hostname and literal path prefix."""

    host: str
    path_prefix: str = "/"
    priority: int = 0

    def __post_init__(self) -> None:
        if not isinstance(self.host, str):
            raise ValueError("host must be a DNS hostname or IPv4 address")
        host = self.host.lower().rstrip(".")
        if not re.fullmatch(r"[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?", host):
            raise ValueError("host must contain only a hostname, not a URL or port")
        if not isinstance(self.path_prefix, str) or not self.path_prefix.startswith("/"):
            raise ValueError("path_prefix must start with /")
        if type(self.priority) is not int:
            raise ValueError("priority must be an integer")
        object.__setattr__(self, "host", host)

    def matches(self, url: str) -> bool:
        try:
            parts = urlsplit(url)
            return (
                parts.scheme in ("http", "https")
                and (parts.hostname or "").lower().rstrip(".") == self.host
                and (parts.path or "/").startswith(self.path_prefix)
            )
        except (ValueError, TypeError):
            return False


@dataclass(frozen=True, slots=True)
class SessionConfig:
    """Immutable settings for a dedicated, owned persistent Chromium context.

    Business projects validate their own headless/path/account policies first.
    Native launch options are passed to Playwright, not reimplemented here.
    """

    user_data_dir: Path
    launch_options: Mapping[str, Any] = field(default_factory=dict, repr=False)
    prefer: tuple[PageRule, ...] = ()
    cleanup_restored: bool = False
    browser_close_fallback: bool = False

    def __post_init__(self) -> None:
        path = Path(self.user_data_dir).expanduser()
        if not path.is_absolute():
            raise ValueError("user_data_dir must be absolute; use from_mapping with base_dir")
        if not isinstance(self.launch_options, Mapping):
            raise ValueError("launch_options must be a mapping")
        if any(not isinstance(key, str) for key in self.launch_options):
            raise ValueError("native launch option names must be strings")
        if "user_data_dir" in self.launch_options:
            raise ValueError("user_data_dir belongs in SessionConfig, not native launch options")
        if self.launch_options.get("channel") and self.launch_options.get("executable_path"):
            raise ValueError("choose channel or executable_path, not both")
        if type(self.cleanup_restored) is not bool or type(self.browser_close_fallback) is not bool:
            raise ValueError("cleanup_restored and browser_close_fallback must be booleans")
        rules = tuple(self.prefer)
        if not all(isinstance(rule, PageRule) for rule in rules):
            raise ValueError("prefer must contain PageRule objects")
        object.__setattr__(self, "user_data_dir", path.resolve())
        object.__setattr__(self, "launch_options", _freeze(self.launch_options))
        object.__setattr__(self, "prefer", rules)

    def launch_kwargs(self) -> dict[str, Any]:
        result = _thaw(self.launch_options)
        result["user_data_dir"] = str(self.user_data_dir)
        return result

    @classmethod
    def from_mapping(cls, data: Mapping[str, Any], *, base_dir: Path) -> SessionConfig:
        if not isinstance(data, Mapping):
            raise ValueError("configuration must be a mapping")
        allowed = {"schema_version", "user_data_dir", "launch", "prefer", "cleanup_restored", "browser_close_fallback"}
        unknown = set(data) - allowed
        if unknown:
            raise ValueError(f"unknown configuration keys: {sorted(map(str, unknown))}")
        if type(data.get("schema_version")) is not int or data["schema_version"] != 1:
            raise ValueError("schema_version must be 1")
        base = Path(base_dir).expanduser()
        if not base.is_absolute():
            raise ValueError("base_dir must be absolute")
        raw = data.get("user_data_dir")
        if not isinstance(raw, (str, Path)) or not str(raw).strip():
            raise ValueError("user_data_dir is required")
        path = Path(raw).expanduser()
        if not path.is_absolute():
            path = base / path
        rules = data.get("prefer", [])
        if not isinstance(rules, (tuple, list)):
            raise ValueError("prefer must be an array of rule mappings")
        try:
            parsed = tuple(PageRule(**rule) for rule in rules)
        except TypeError as exc:
            raise ValueError("each prefer rule must have host, optional path_prefix and priority") from exc
        return cls(path, data.get("launch", {}), parsed,
                   data.get("cleanup_restored", False), data.get("browser_close_fallback", False))
