"""Shared resource ownership with native Playwright objects.

Importing this library does not import Playwright, start a browser, read business
configuration or install anything. Use the caller's process and execution lane.
"""
from .async_session import AsyncSession
from .config import PageRule, SessionConfig
from .errors import ExecutionContextError, PageCleanupError, ResourceUnavailableError, SessionStateError
from .results import PageCleanupItem, PageCleanupReport, ReleaseReport, ResourceFailure, SessionSnapshot
from .sync_session import SyncSession

__all__ = [
    "AsyncSession", "SyncSession", "SessionConfig", "PageRule",
    "ExecutionContextError", "PageCleanupError", "ResourceUnavailableError", "SessionStateError",
    "PageCleanupItem", "PageCleanupReport", "ReleaseReport", "ResourceFailure", "SessionSnapshot",
]
