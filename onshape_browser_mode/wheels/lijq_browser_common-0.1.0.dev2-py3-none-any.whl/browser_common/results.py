"""Resource reports contain operation/type evidence, never page contents."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True, slots=True)
class ResourceFailure:
    operation: str
    error_type: str


@dataclass(frozen=True, slots=True)
class PageCleanupItem:
    page: Any = field(repr=False)
    status: str
    error_type: str | None = None


@dataclass(frozen=True, slots=True)
class PageCleanupReport:
    items: tuple[PageCleanupItem, ...] = ()

    @property
    def complete(self) -> bool:
        return all(item.status in ("closed", "already_closed", "protected") for item in self.items)


@dataclass(frozen=True, slots=True)
class ReleaseReport:
    context_status: str = "absent"
    driver_status: str = "absent"
    browser_fallback_used: bool = False
    failures: tuple[ResourceFailure, ...] = ()

    @property
    def complete(self) -> bool:
        return self.context_status in ("absent", "closed") and self.driver_status in ("absent", "stopped")

    @property
    def failures_summary(self) -> str:
        """Stable type-only rendering in recorded order; empty failures = 'none'."""
        return ",".join(f"{item.operation}:{item.error_type}" for item in self.failures) or "none"

    @property
    def clean(self) -> bool:
        """All resources released without a recorded failure or browser fallback."""
        return self.complete and not self.failures and not self.browser_fallback_used


@dataclass(frozen=True, slots=True)
class SessionSnapshot:
    state: str
    generation: int
    has_context: bool
    has_page: bool
    pending_pages: int
