"""Internal ownership and selection rules shared by sync/async executors."""
from __future__ import annotations

import math
import threading
import time
from typing import Any

from .config import SessionConfig
from .errors import ExecutionContextError, ResourceUnavailableError, SessionStateError
from .results import PageCleanupReport, ReleaseReport, SessionSnapshot


def live(page: Any) -> bool:
    # A native inspection error is not evidence that a page is closed.
    return page is not None and not page.is_closed()


def deadline(budget_ms: float | None) -> float | None:
    if budget_ms is None:
        return None
    if isinstance(budget_ms, bool) or not isinstance(budget_ms, (int, float)) or not math.isfinite(budget_ms) or budget_ms < 0:
        raise ValueError("budget_ms must be finite and nonnegative, or None")
    return time.monotonic() + budget_ms / 1000


class SessionCore:
    def __init__(self, config: SessionConfig, playwright_factory: Any, after_context_created: Any) -> None:
        if not isinstance(config, SessionConfig):
            raise TypeError("config must be SessionConfig")
        self.config = config
        self._factory = playwright_factory
        self._after_create = after_context_created
        self._manager: Any = None
        self._driver: Any = None
        self._context: Any = None
        self._context_listener: Any = None
        self._page: Any = None
        self._context_closed = False
        self._thread: int | None = None
        self._state = "new"
        self._generation = 0
        self._scopes: set[Any] = set()
        self._tracked: dict[int, tuple[Any, Any]] = {}
        self._pending: dict[int, Any] = {}
        self._closing_pages: set[int] = set()
        self.last_release_report: ReleaseReport | None = None
        self.last_cleanup_report: PageCleanupReport | None = None

    def _assert_access(self) -> None:
        if self._thread is not None and self._thread != threading.get_ident():
            raise ExecutionContextError(
                f"Session belongs to a different thread; owner_thread={self._thread}, "
                f"current_thread={threading.get_ident()}. Read session data in its owning execution context."
            )

    def _pin(self) -> None:
        self._assert_access()
        if self._thread is None:
            self._thread = threading.get_ident()

    @property
    def context(self) -> Any:
        self._assert_access()
        if self._context is None or self._context_closed:
            raise ResourceUnavailableError("No live context; call start explicitly or release invalid resources")
        return self._context

    @property
    def page(self) -> Any:
        self._assert_access()
        if self._context is None or self._context_closed or not live(self._page):
            raise ResourceUnavailableError("No live working page; explicitly adopt a page or release")
        return self._page

    def snapshot(self) -> SessionSnapshot:
        self._assert_access()
        return SessionSnapshot(self._state, self._generation,
                               self._context is not None and not self._context_closed,
                               self._context is not None and not self._context_closed and live(self._page),
                               len(self._pending))

    def _require_ready(self) -> None:
        self._assert_access()
        if self._state != "ready" or self._context is None or self._context_closed:
            raise SessionStateError("Operation requires a ready context")

    def _validate_pages(self, pages: Any) -> list[Any]:
        self._assert_access()
        if self._context is None:
            raise ResourceUnavailableError("No context owns these pages")
        result: list[Any] = []
        seen: set[int] = set()
        # Validate the entire snapshot before the first close.
        for page in pages:
            if getattr(page, "context", None) is not self._context:
                raise SessionStateError("Page belongs to a different context")
            if id(page) in self._closing_pages:
                raise SessionStateError("Page cleanup is already in progress")
            if id(page) not in seen:
                result.append(page)
                seen.add(id(page))
        return result

    def adopt_page(self, page: Any) -> Any:
        self._require_ready()
        self._validate_pages([page])
        if not live(page):
            raise ResourceUnavailableError("Cannot adopt a closed page")
        tracked = self._tracked.get(id(page))
        if tracked and tracked[1]._closing:
            raise SessionStateError("Cannot adopt a page while its scope is closing")
        self._page = page
        if tracked:
            tracked[1]._pages.pop(id(page), None)
            self._tracked.pop(id(page), None)
        self._pending.pop(id(page), None)
        return page

    def _protected(self, page: Any, scope: Any = None) -> bool:
        tracked = self._tracked.get(id(page))
        return page is self._page or (tracked is not None and tracked[1] is not scope)

    def _select_page(self, pages: list[Any]) -> Any:
        candidates = [page for page in pages if live(page)]
        matches: list[tuple[int, int, Any]] = []
        for index, page in enumerate(candidates):
            try:
                priorities = [rule.priority for rule in self.config.prefer if rule.matches(page.url)]
            except Exception:
                priorities = []
            if priorities:
                matches.append((-max(priorities), index, page))
        return min(matches, key=lambda match: match[:2])[2] if matches else (candidates[0] if candidates else None)

    def _on_context_closed(self, *_: Any) -> None:
        self._context_closed = True
        if self._state == "ready":
            self._state = "invalidated"
        self._page = None
        self._pending.clear()

    def _attach_context(self) -> None:
        self._context_closed = False
        context = self._context

        def closed(*_: Any) -> None:
            if self._context is context:
                self._on_context_closed()

        self._context_listener = closed
        context.on("close", closed)

    def _forget_context(self) -> None:
        # Remove only our own subscription, never business listeners.
        if self._context is not None and self._context_listener is not None:
            try:
                self._context.remove_listener("close", self._context_listener)
            except Exception:
                pass  # The resource is already closed; stale callback checks identity.
        self._context = None
        self._context_listener = None
        self._page = None

    def _record_cleanup(self, report: PageCleanupReport) -> PageCleanupReport:
        self.last_cleanup_report = report
        for item in report.items:
            if item.status in ("closed", "already_closed"):
                self._pending.pop(id(item.page), None)
            elif item.status in ("failed", "not_attempted", "unknown"):
                self._pending[id(item.page)] = item.page
        return report

    def _begin_start(self) -> None:
        if self._state in ("starting", "releasing"):
            raise SessionStateError("Lifecycle reentry is not allowed")
        if self._context is not None or self._driver is not None or self._manager is not None:
            raise SessionStateError("Release retained resources before starting again")
        self._state = "starting"
        self._context_closed = False

    def _begin_release(self) -> None:
        if self._scopes or self._closing_pages:
            raise SessionStateError("Exit active temporary/cleanup scopes before release")
        if self._state in ("starting", "releasing"):
            raise SessionStateError("Lifecycle reentry is not allowed")
        self._state = "releasing"

    def _finish_release(self, report: ReleaseReport) -> ReleaseReport:
        self.last_release_report = report
        self._state = "closed" if report.complete else "release_failed"
        if report.complete:
            self._page = None
            self._pending.clear()
            self._tracked.clear()
        return report


class TemporaryCore:
    def __init__(self, session: SessionCore, budget_ms: float | None) -> None:
        # Validate now, but measure the budget only when cleanup begins.
        deadline(budget_ms)
        self.session = session
        self.budget_ms = budget_ms
        self._pages: dict[int, Any] = {}
        self._active = False
        self._entered = False
        self._closing = False
        self.report: PageCleanupReport | None = None

    def _enter(self) -> None:
        self.session._require_ready()
        if self._entered:
            raise SessionStateError("Temporary scope can only be entered once")
        self._entered = self._active = True
        self.session._scopes.add(self)

    def track(self, page: Any) -> Any:
        self.session._require_ready()
        if not self._active or self._closing:
            raise SessionStateError("Temporary scope is not accepting pages")
        self.session._validate_pages([page])
        if page is self.session._page:
            raise SessionStateError("The working page is not temporary")
        if not live(page):
            raise ResourceUnavailableError("Cannot track a closed page")
        previous = self.session._tracked.get(id(page))
        if previous and previous[1] is not self:
            raise SessionStateError("Page already belongs to another temporary scope")
        self._pages[id(page)] = page
        self.session._tracked[id(page)] = (page, self)
        return page

    def try_track(self, page: Any) -> bool:
        """Skip None/closed same-context pages; never suppress ownership errors."""
        self.session._require_ready()
        if not self._active or self._closing:
            raise SessionStateError("Temporary scope is not accepting pages")
        if page is None:
            return False
        self.session._validate_pages([page])
        if page is self.session._page:
            raise SessionStateError("The working page is not temporary")
        previous = self.session._tracked.get(id(page))
        if previous and previous[1] is not self:
            raise SessionStateError("Page already belongs to another temporary scope")
        if not live(page):
            return False
        self._pages[id(page)] = page
        self.session._tracked[id(page)] = (page, self)
        return True

    def _finish(self) -> None:
        self.session._scopes.discard(self)
        confirmed = {id(item.page) for item in self.report.items
                     if item.status in ("closed", "already_closed")} if self.report else set()
        for key, page in self._pages.items():
            tracked = self.session._tracked.get(key)
            if tracked and tracked[1] is self:
                self.session._tracked.pop(key)
            # Do not perform fallible native inspection while unwinding a
            # business exception. Unknown pages remain owned for later release.
            if key not in confirmed and page is not self.session._page and not self.session._context_closed:
                self.session._pending[key] = page
        self._active = False
        self._closing = False
