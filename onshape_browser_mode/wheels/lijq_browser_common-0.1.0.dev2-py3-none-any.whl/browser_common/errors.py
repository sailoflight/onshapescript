"""Library errors; native business exceptions remain native exceptions."""
from .results import PageCleanupReport


class SessionStateError(RuntimeError):
    """The requested transition would violate resource ownership."""


class ResourceUnavailableError(SessionStateError):
    """Explicit start or page adoption is required; no implicit recovery occurs."""


class ExecutionContextError(SessionStateError):
    """A native resource was accessed outside its owning thread or event loop."""


class PageCleanupError(RuntimeError):
    def __init__(self, report: PageCleanupReport) -> None:
        self.report = report
        super().__init__("Page cleanup incomplete; inspect report and release or reconcile remaining resources")
