"""Async resource owner using the caller's event loop, never a private loop."""
from __future__ import annotations

import asyncio
import time
from typing import Any

from ._core import SessionCore, TemporaryCore, deadline
from .config import SessionConfig
from .errors import ExecutionContextError, PageCleanupError, SessionStateError
from .results import PageCleanupItem, PageCleanupReport, ReleaseReport, ResourceFailure


class AsyncSession(SessionCore):
    def __init__(self, config: SessionConfig, *, playwright_factory: Any = None,
                 after_context_created: Any = None) -> None:
        super().__init__(config, playwright_factory, after_context_created)
        self._loop: Any = None
        self._lock = asyncio.Lock()
        self._lifecycle_task: Any = None

    def _assert_access(self) -> None:
        super()._assert_access()
        if self._loop is not None:
            try:
                current = asyncio.get_running_loop()
            except RuntimeError as exc:
                raise ExecutionContextError(
                    f"AsyncSession requires its owning running loop; owner_loop={id(self._loop)}, "
                    f"current_loop=none, owner_thread={self._thread}. "
                    "Collect session data inside the owning loop; assert on copied data outside."
                ) from exc
            if current is not self._loop:
                raise ExecutionContextError(
                    f"AsyncSession belongs to a different event loop; owner_loop={id(self._loop)}, "
                    f"current_loop={id(current)}, owner_thread={self._thread}. "
                    "Use the owning loop; do not create another asyncio.run for this session."
                )

    def _pin(self) -> None:
        super()._pin()
        if self._loop is None:
            self._loop = asyncio.get_running_loop()

    def _check_reentry(self) -> None:
        self._pin()
        if self._lifecycle_task is asyncio.current_task():
            raise SessionStateError("Lifecycle callbacks must not reenter start/release")

    async def start(self) -> Any:
        self._check_reentry()
        async with self._lock:
            if self._state == "ready":
                return self.page
            self._begin_start()
            self._lifecycle_task = asyncio.current_task()
            try:
                factory = self._factory
                if factory is None:
                    from playwright.async_api import async_playwright
                    factory = async_playwright
                self._manager = factory()
                self._driver = await self._manager.start()
                self._context = await self._driver.chromium.launch_persistent_context(**self.config.launch_kwargs())
                self._attach_context()
                restored = list(self._context.pages)
                if self._after_create is not None:
                    await self._after_create(self._context)
                self._page = self._select_page(restored)
                if self._page is None:
                    self._page = await self._context.new_page()
                if self.config.cleanup_restored:
                    report = await self._cleanup(restored)
                    if not report.complete:
                        raise PageCleanupError(report)
                self.page
                self._generation += 1
                self._state = "ready"
                return self._page
            except BaseException as original:
                try:
                    await self._release_resources()
                except BaseException as cleanup_error:
                    original.add_note(f"Startup cleanup interrupted: {type(cleanup_error).__name__}; inspect last_release_report")
                if self.last_release_report is not None and self.last_release_report.complete:
                    self._state = "start_failed"
                original.add_note("Explicit startup failed; inspect session.last_release_report before retrying")
                raise
            finally:
                self._lifecycle_task = None

    async def _cleanup(self, pages: Any, *, budget_ms: float | None = None,
                       scope: Any = None) -> PageCleanupReport:
        candidates = self._validate_pages(pages)
        end = deadline(budget_ms)
        items: list[PageCleanupItem] = []
        for index, page in enumerate(candidates):
            if self._protected(page, scope):
                items.append(PageCleanupItem(page, "protected"))
                continue
            if id(page) in self._closing_pages:
                items.append(PageCleanupItem(page, "not_attempted", "SessionStateError"))
                continue
            if end is not None and time.monotonic() >= end:
                items.append(PageCleanupItem(page, "not_attempted"))
                continue
            # No awaits between checking ownership and marking this page busy.
            self._closing_pages.add(id(page))
            try:
                if page.is_closed():
                    items.append(PageCleanupItem(page, "already_closed"))
                else:
                    await page.close()
                    items.append(PageCleanupItem(page, "closed"))
            except Exception as exc:
                items.append(PageCleanupItem(page, "failed", type(exc).__name__))
            except BaseException as exc:
                items.append(PageCleanupItem(page, "unknown", type(exc).__name__))
                items.extend(PageCleanupItem(p, "not_attempted") for p in candidates[index + 1:])
                report = self._record_cleanup(PageCleanupReport(tuple(items)))
                if scope is not None:
                    scope.report = report
                raise
            finally:
                self._closing_pages.discard(id(page))
        report = self._record_cleanup(PageCleanupReport(tuple(items)))
        if scope is not None:
            scope.report = report
        return report

    async def reconcile_pages(self, pages: Any, *, budget_ms: float | None = None) -> PageCleanupReport:
        self._require_ready()
        return await self._cleanup(pages, budget_ms=budget_ms)

    def temporary_pages(self, *, budget_ms: float | None = None) -> AsyncTemporaryPages:
        self._require_ready()
        return AsyncTemporaryPages(self, budget_ms)

    async def release(self) -> ReleaseReport:
        self._check_reentry()
        async with self._lock:
            self._begin_release()
            self._lifecycle_task = asyncio.current_task()
            try:
                return await self._release_resources()
            finally:
                self._lifecycle_task = None

    async def _release_resources(self) -> ReleaseReport:
        context_status = "absent" if self._context is None else "unknown"
        driver_status = "absent" if self._manager is None and self._driver is None else "skipped"
        fallback = False
        failures: list[ResourceFailure] = []
        try:
            if self._context is not None:
                if not self._context_closed:
                    try:
                        await self._context.close()
                        self._context_closed = True
                    except Exception as exc:
                        failures.append(ResourceFailure("context.close", type(exc).__name__))
                        if not self._context_closed and self.config.browser_close_fallback:
                            try:
                                browser = self._context.browser
                                if browser is not None:
                                    fallback = True
                                    await browser.close()
                                    self._context_closed = True
                            except Exception as inner:
                                failures.append(ResourceFailure("browser.close", type(inner).__name__))
                context_status = "closed" if self._context_closed else "failed"
                if self._context_closed:
                    self._forget_context()
            if self._context is None and (self._driver is not None or self._manager is not None):
                driver_status = "unknown"
                try:
                    if self._driver is not None:
                        await self._driver.stop()
                    else:
                        await self._manager.__aexit__(None, None, None)
                    self._driver = self._manager = None
                    driver_status = "stopped"
                except Exception as exc:
                    driver_status = "failed"
                    failures.append(ResourceFailure("driver.stop", type(exc).__name__))
        finally:
            self._finish_release(ReleaseReport(context_status, driver_status, fallback, tuple(failures)))
        return self.last_release_report


class AsyncTemporaryPages(TemporaryCore):
    async def __aenter__(self) -> AsyncTemporaryPages:
        self._enter()
        return self

    async def __aexit__(self, exc_type: Any, exc: Any, traceback: Any) -> bool:
        self.session._assert_access()
        self._closing = True
        try:
            self.report = await self.session._cleanup(list(self._pages.values()), budget_ms=self.budget_ms, scope=self)
        finally:
            self._finish()
        if not self.report.complete:
            if exc is not None:
                exc.add_note("Temporary page cleanup incomplete; inspect scope.report and session snapshot")
            else:
                raise PageCleanupError(self.report)
        return False
