"""Synchronous resource owner. No browser starts until start() is called."""
from __future__ import annotations

import inspect
import threading
import time
from typing import Any

from ._core import SessionCore, TemporaryCore, deadline
from .config import SessionConfig
from .errors import PageCleanupError
from .results import PageCleanupItem, PageCleanupReport, ReleaseReport, ResourceFailure


def _sync(value: Any) -> Any:
    if inspect.isawaitable(value):
        if inspect.iscoroutine(value):
            value.close()
        raise TypeError("SyncSession requires synchronous Playwright objects and callbacks")
    return value


class SyncSession(SessionCore):
    def __init__(self, config: SessionConfig, *, playwright_factory: Any = None,
                 after_context_created: Any = None) -> None:
        super().__init__(config, playwright_factory, after_context_created)
        self._lock = threading.RLock()

    def start(self) -> Any:
        with self._lock:
            self._pin()
            if self._state == "ready":
                return self.page
            self._begin_start()
            try:
                factory = self._factory
                if factory is None:
                    from playwright.sync_api import sync_playwright
                    factory = sync_playwright
                self._manager = factory()
                self._driver = _sync(self._manager.start())
                self._context = _sync(self._driver.chromium.launch_persistent_context(**self.config.launch_kwargs()))
                self._attach_context()
                restored = list(self._context.pages)
                if self._after_create is not None:
                    _sync(self._after_create(self._context))
                self._page = self._select_page(restored)
                if self._page is None:
                    self._page = _sync(self._context.new_page())
                if self.config.cleanup_restored:
                    report = self._cleanup(restored)
                    if not report.complete:
                        raise PageCleanupError(report)
                # A callback/native close must not turn a dead context into READY.
                self.page
                self._generation += 1
                self._state = "ready"
                return self._page
            except BaseException as original:
                try:
                    self._release_resources()
                except BaseException as cleanup_error:
                    original.add_note(f"Startup cleanup interrupted: {type(cleanup_error).__name__}; inspect last_release_report")
                if self.last_release_report is not None and self.last_release_report.complete:
                    self._state = "start_failed"
                original.add_note("Explicit startup failed; inspect session.last_release_report before retrying")
                raise

    def _cleanup(self, pages: Any, *, budget_ms: float | None = None,
                 scope: Any = None) -> PageCleanupReport:
        candidates = self._validate_pages(pages)
        end = deadline(budget_ms)
        items: list[PageCleanupItem] = []
        for index, page in enumerate(candidates):
            if self._protected(page, scope):
                items.append(PageCleanupItem(page, "protected"))
                continue
            if end is not None and time.monotonic() >= end:
                items.append(PageCleanupItem(page, "not_attempted"))
                continue
            self._closing_pages.add(id(page))
            try:
                if page.is_closed():
                    items.append(PageCleanupItem(page, "already_closed"))
                else:
                    _sync(page.close())
                    items.append(PageCleanupItem(page, "closed"))
            except Exception as exc:
                items.append(PageCleanupItem(page, "failed", type(exc).__name__))
            except BaseException as exc:
                items.append(PageCleanupItem(page, "unknown", type(exc).__name__))
                items.extend(PageCleanupItem(p, "not_attempted") for p in candidates[index + 1:])
                report = self._record_cleanup(PageCleanupReport(tuple(items)))
                if scope is not None:
                    scope.report = report
                raise
            finally:
                self._closing_pages.discard(id(page))
        report = self._record_cleanup(PageCleanupReport(tuple(items)))
        if scope is not None:
            scope.report = report
        return report

    def reconcile_pages(self, pages: Any, *, budget_ms: float | None = None) -> PageCleanupReport:
        self._require_ready()
        return self._cleanup(pages, budget_ms=budget_ms)

    def temporary_pages(self, *, budget_ms: float | None = None) -> SyncTemporaryPages:
        self._require_ready()
        return SyncTemporaryPages(self, budget_ms)

    def release(self) -> ReleaseReport:
        with self._lock:
            self._pin()
            self._begin_release()
            return self._release_resources()

    def _release_resources(self) -> ReleaseReport:
        context_status = "absent" if self._context is None else "unknown"
        driver_status = "absent" if self._manager is None and self._driver is None else "skipped"
        fallback = False
        failures: list[ResourceFailure] = []
        try:
            if self._context is not None:
                if not self._context_closed:
                    try:
                        _sync(self._context.close())
                        self._context_closed = True
                    except Exception as exc:
                        failures.append(ResourceFailure("context.close", type(exc).__name__))
                        if not self._context_closed and self.config.browser_close_fallback:
                            try:
                                browser = self._context.browser
                                if browser is not None:
                                    fallback = True
                                    _sync(browser.close())
                                    self._context_closed = True
                            except Exception as inner:
                                failures.append(ResourceFailure("browser.close", type(inner).__name__))
                context_status = "closed" if self._context_closed else "failed"
                if self._context_closed:
                    self._forget_context()
            if self._context is None and (self._driver is not None or self._manager is not None):
                driver_status = "unknown"
                try:
                    if self._driver is not None:
                        _sync(self._driver.stop())
                    else:
                        _sync(self._manager.__exit__(None, None, None))
                    self._driver = self._manager = None
                    driver_status = "stopped"
                except Exception as exc:
                    driver_status = "failed"
                    failures.append(ResourceFailure("driver.stop", type(exc).__name__))
        finally:
            self._finish_release(ReleaseReport(context_status, driver_status, fallback, tuple(failures)))
        return self.last_release_report


class SyncTemporaryPages(TemporaryCore):
    def __enter__(self) -> SyncTemporaryPages:
        self._enter()
        return self

    def __exit__(self, exc_type: Any, exc: Any, traceback: Any) -> bool:
        self.session._assert_access()
        self._closing = True
        try:
            self.report = self.session._cleanup(list(self._pages.values()), budget_ms=self.budget_ms, scope=self)
        finally:
            self._finish()
        if not self.report.complete:
            if exc is not None:
                exc.add_note("Temporary page cleanup incomplete; inspect scope.report and session snapshot")
            else:
                raise PageCleanupError(self.report)
        return False
