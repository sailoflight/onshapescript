# browser_common 适配行为手册

适用版本：`lijq-browser-common 0.1.0.dev2`。面向将已有项目接入本库的 agents 和开发者。

本手册描述实际首版 API；早期 DESIGN / CONFIGURATION_OPTIONS 中未出现在这里的接口和 TOML 结构属于历史提案，不能直接当成已实现能力。源码及离线契约测试是行为依据。

## 1. 适配目标与完成边界

本库是进程内纯 Python 库，无 main、CLI、MCP 服务或后台事件循环。目标是中共享：由 Session 持有独占的原生 driver/context 和唯一工作页，业务直接使用 Playwright Page/Frame/Locator、脚本和事件。

当前实现：同步／异步持久 Chromium Session、启动及部分失败清理、原生对象访问、配置选页、可选启动快照清理、显式接管、临时页作用域、明确候选清理、分项释放结果、执行线程／事件循环检查。

当前不实现：外部 borrowed context/CDP 接管、跨进程 profile 锁或工作流租约、自动重启、自动登录／验证码处理、业务步骤 DSL、动作限速、通用硬关闭超时。真实站点和浏览器行为尚未实机验收；首版以 fake 离线契约验证，不等同于业务适配已经完成。

## 2. Agent 接入顺序

1. 先查本手册和目标项目当前 Session、退出入口、page 写入、new_page/close、popup 返回与消费者。
2. 记录旧版本、依赖、配置路径和未提交修改，备份后逐点适配；不移动或清空登录 profile。
3. 业务原配置继续按原优先级合并，并先执行自己的路径／headless／账号约束，再转成 SessionConfig。
4. 保留业务 Session 作为组合门面；原生资源只由一个公共 Session 持有，属性委托，不复制 `_page` 或 `_context`。
5. 从应用 lifespan 调用 start/release；不在每个工具调用后释放浏览器。
6. 页面接管和临时页 producer→consumer 链一起修改、测试；不要只改返回 popup 的一端。
7. 对照旧公共工具 schema、错误和状态输出。新释放报告要明确映射，不能直接替换业务响应。
8. 离线回归后再安排隔离 profile、本地页面的浏览器验证；真实站点另行按业务项目权限执行。

完成指标：资源所有者唯一，原生调用仍可用，失败不误报成功，临时页不误关，业务逻辑没有泄漏进公共库。业务仍 import playwright 是正常用法。

## 3. 安装、导入和依赖

分发名 `lijq-browser-common`，导入名 `browser_common`。当前以本地 wheel 分发；在业务自己的环境安装锁定版本，不配置 sys.path 指向另一个项目源码。

包声明 `playwright>=1.40,<2`；这是依赖约束，不表示其中所有版本和浏览器通道都已实机验证。运行默认 start 需要业务环境已有 Playwright 和对应浏览器。库不安装任何软件或浏览器。

导入配置、Session 和报告不导入 Playwright，不读业务配置，不创建 profile。默认 start 才按需导入 `playwright.sync_api` 或 `playwright.async_api`。未安装时原始 ImportError 传播，同时可检查启动清理报告。

本手册随 wheel 携带，安装后可读取：

```python
from importlib.resources import files
text = files("browser_common").joinpath("docs", "ADAPTATION_GUIDE.md").read_text(encoding="utf-8")
```

## 4. 首版配置：只读数据，不自动找文件

```toml
schema_version = 1
user_data_dir = "user_data/browser_profile"
cleanup_restored = false
browser_close_fallback = false

[launch]
channel = "chrome"
headless = false
locale = "zh-CN"
timezone_id = "Asia/Shanghai"

[launch.viewport]
width = 1280
height = 800

[[prefer]]
host = "cad.onshape.com"
path_prefix = "/documents"
priority = 100
```

这是示例，不自动应用到 Onshape 或淘宝。业务自己读 TOML：

```python
from pathlib import Path
from browser_common import SessionConfig

config = SessionConfig.from_mapping(
    {"schema_version": 1, "user_data_dir": "user_data/browser_profile",
     "launch": {"headless": False}},
    base_dir=Path("/absolute/business/project"),
)
```

- mapping 必须显式 `schema_version=1`、user_data_dir；未知公共字段报错。
- base_dir 必须绝对；相对 profile 以它解析，不取 cwd。直接构造 SessionConfig 时 user_data_dir 必须为绝对路径。
- 原生参数放 `launch`；`user_data_dir` 不允许重复放在 launch 中。channel 和 executable_path 不能同时为非空值。
- 配置会复制并冻结，launch_kwargs 返回独立副本；新配置不热更新已存在的 Session。
- prefer 按精确 hostname、HTTP(S) URL、literal path prefix 匹配，priority 较高优先；平局保持页面快照顺序。无匹配采用首个存活页，无存活页则原生 new_page。
- URL 选择不是认证判定。Onshape 当前选页判断更宽，接入新规则需要业务兼容测试。
- cleanup_restored 默认 false；启用时只清理新建 context 时取得的恢复页快照，并保护选中页。初始化回调之后出现的新页面不自动加入该快照。
- 原生 launch 参数的其他校验由 Playwright 负责。业务配置中的路径／headless／额度硬规则必须保留，不由公共配置取代。

也可以直接使用 `SessionConfig(Path(...), launch_options={...}, prefer=(PageRule(...),))`。无需为配置接入安装框架或建立站点插件目录。

## 5. 同步／异步用法

以下函数由业务程序调用；示例不会在 import 时执行浏览器操作。

```python
from browser_common import SyncSession

def run_business(config):
    session = SyncSession(config)
    try:
        page = session.start()
        assert page is session.page
        assert page.context is session.context
        # 业务直接调用原生 page.locator/evaluate/frames/expect_popup 等。
    finally:
        report = session.release()
        if not report.complete:
            # 保留 session 供受控再次 release，不继续当作已关闭。
            handle_release_failure(session, report)
```

```python
from browser_common import AsyncSession

async def run_business_async(config):
    session = AsyncSession(config)
    try:
        page = await session.start()
        # await page.locator(...).click() 等业务原生操作。
    finally:
        report = await session.release()
        if not report.complete:
            handle_release_failure(session, report)
```

`handle_release_failure` 是业务提供的示意函数，不是本库 API。MCP 的整个 lifespan 通常对应上面的 try/finally；业务工具只复用 session，不重复创建 owner。

- `start()` 返回原生工作页。ready 状态再次 start 只返回当前页，不重选、不探活 evaluate、不清理、不登录。
- `page/context` 是只读属性，不隐式启动、恢复或清理。不可用时抛 ResourceUnavailableError。
- 工作页被关闭时，显式接管同 context 的新页；context 被关闭时先 release，再明确决定是否 start。库不自动重放业务操作。
- 新一次成功启动 generation 增加；snapshot 只给资源状态，不返回登录或业务成功结论。
- 无资源 release 不启动浏览器，返回 complete 报告。

## 6. 原生页面接管与临时页责任

两种 Session 的 `adopt_page` 和 `scope.track` 都是同步方法：只更新同线程／循环中的归属，不执行网络操作。

```python
new_page = session.context.new_page()  # 同步示例，仍是原生 API
old_page = session.page
session.adopt_page(new_page)
# 接管不会自动关旧页。业务决定何时协调清理。
report = session.reconcile_pages([old_page])
```

adopt 拒绝其他 context 的页、已关闭页、清理中的页；接管临时页时原子地从作用域移除清理责任。新页先由 owner 保存，旧页关闭失败不会让新页丢失。

```python
with session.temporary_pages() as scope:
    popup = scope.track(session.context.new_page())
    # 在 popup 上执行原生业务操作。
# 正常退出后检查报告；失败时本库已抛 PageCleanupError。
assert scope.report.complete
```

```python
async with session.temporary_pages() as scope:
    async with session.page.expect_popup() as event:
        await business_link.click()
    popup = scope.track(await event.value)
    await inspect_business_popup(popup)
    # 如需变成工作页：session.adopt_page(popup)，退出将不再关闭它。
```

`business_link`、`inspect_business_popup` 是业务对象／函数。这里不会改变入口点击、添加导航兜底或把 popup 不存在解释为使用当前页。

scope 规则：只使用一次；只能在进入后登记；不能登记当前页或其他 scope 已登记的页；重复登记自己的同一页幂等。已关闭的页可由清理识别。退出时只关闭本 scope 仍负责的页面，不关未知／人工新页。

若清理失败而业务无异常，抛 `PageCleanupError`，其 `.report` 可读取，scope.report 也保留。若业务已有普通异常，保留该异常并加 cleanup note。未完成页仍由 session 记录，可协调或 release，不能忽略后丢弃 session。

捕获 popup 之前取消的窗口没有被自动处理：只有 track 后的页受 scope 管理。首版不声称零泄漏捕获，也不扫描页面差集去关不明归属页面。

## 6.1 可选返回值与长流程（dev2）

`scope.try_track(page) -> bool` 在同步／异步 scope 都是同步方法。仅 `None` 或同 context 的已关闭页返回 False；存活页登记成功返回 True，重复登记自己的页仍为 True。它不返回 Page，调用方继续使用原变量。严格 `track()` 保持原契约。

scope 未进入／已退出／关闭中、错误线程或循环、其他 context、当前工作页、其他 scope 已登记页仍报错；即使对象已关闭也不跳过所有权检查。原生 is_closed 抛错照常传播。False 只表示未登记，不代表业务结果成功或页面内容仍可访问。

```python
async with session.temporary_pages() as scope:
    popup = await produce_popup()  # 业务函数，可能返回 None 或已关闭的同 context 页面
    if scope.try_track(popup):
        await inspect_business_popup(popup)
```

长流程优先提取内层业务函数再包裹；需要延迟进入 scope 或组合多个 context manager 时，可用标准库 AsyncExitStack。同步场景对应 ExitStack。示例中的 produce_popup/inspect_business_popup 均为业务函数：

```python
from contextlib import AsyncExitStack

async def inspect_long_flow(session):
    async with AsyncExitStack() as stack:
        # 前置业务步骤可放这里；资源产生前先进入 scope。
        scope = await stack.enter_async_context(session.temporary_pages())
        popup = await produce_popup()
        if scope.try_track(popup):
            return await inspect_business_popup(popup)
```

AsyncExitStack 不消除外层缩进，但避免为了延迟登记再次嵌套大段代码，并将业务异常传给 scope 的退出方法。不要用 `finally: await stack.aclose()` 替代上述用法：aclose 不接收原业务异常，清理失败可能顶替它。本版不增加 finish()，现有业务异常优先规则保持。

## 7. 明确候选协调与预算

`reconcile_pages(pages, budget_ms=None)` 接收显式候选快照；AsyncSession 对应 await。先检查整个集合是否同 context，再执行任何关闭；按身份去重。

- 当前工作页和活跃 scope 登记页标记 protected，不关闭。
- status 可为 closed、already_closed、protected、failed、not_attempted、unknown。
- 报告 complete 只允许前三种。错误只记录类型，不复制网页或异常文本；item.page 是原生引用，仅供本地处置，不应直接序列化发给 MCP 客户端。
- budget_ms 可选，是两次关闭之间检查的协作预算。耗尽则剩余候选 not_attempted；不是原生 Page.close 的 timeout 参数，不能中断同步阻塞调用。
- 不自动 bring_to_front、导航或恢复登录。新出现但不在快照中的页不受影响。
- 活跃 scope 期间禁止 release；先退出 scope，避免停止他人仍在使用的 context。

## 8. 释放、异常和取消

`ReleaseReport` 提供 context_status、driver_status、browser_fallback_used、failures、complete 和 clean。complete 表示拥有资源已释放；clean 还要求没有记录的失败和 Browser 回退。回退释放成功时可以 complete=true、clean=false，业务记录诊断而不必把已释放资源继续当作未释放。

| 状况 | 首版行为 |
|---|---|
| context.close 成功，driver.stop 成功 | 完成，清除已释放句柄；重复 release 幂等 |
| context.close 失败且未确认关闭 | 保留 context 和 driver；driver_status=skipped，不停止可供重试的 driver |
| 启用 browser_close_fallback | 仅当前 owned persistent 模式，对自己的 Browser 尝试回退；不支持借用外部资源 |
| context 已关闭，driver.stop 失败 | 保留 driver，release_failed；再次 release 重试剩余资源 |
| driver.start 或 launch 失败 | 清理本次已取得的 manager/driver，保留原启动异常及 last_release_report |
| after_context_created 失败 | 清理已创建 context，再停止 driver；保留原异常 |
| 原生资源主动触发 context close | ready 转为 invalidated，不重启；后续 release 清理剩余 driver，完成后才允许显式 start |

`report.failures_summary`（dev2）按原记录顺序输出逗号分隔的 `operation:error_type`，无失败时返回 `"none"`。只使用报告的操作名和错误类型，不包含原始异常文本或页面内容；它是日志便利属性，不改变 complete/clean 的含义，也不能代替两者判断。手工创建 ResourceFailure 时仍应仅填操作标识和类型名。

complete 是本进程拥有句柄的释放结果，不是独立核实了操作系统 profile 锁。不能把它当跨进程锁检测。

与原 Onshape 的重要差异：context.close 失败时，首版默认跳过 driver.stop，以保留重试路径；原代码会继续尝试 stop。与淘宝的重要差异：不吞关闭错误后假报 closed。接入时需要单独验收这些有意改进。

取消策略：不创建后台清理任务，不调用 asyncio.run，也不承诺硬清理时限。启动取消后会在当前任务中尝试释放，再传播原取消；如果再次取消打断清理，报告未确认状态并保留句柄。页面关闭中取消记录 unknown／not_attempted，退出 scope 后仍有 session 接管未完成资源；调用方需捕获取消并安排受控 release。release 自己被取消时也保留 last_release_report 和剩余句柄。

上游不能在重复取消后直接丢弃最后一个 session 引用并指望库自动回收。也不能把 await 超时理解为浏览器端操作没有发生。

## 9. 执行上下文与初始化扩展

SyncSession 第一次生命周期调用绑定线程；AsyncSession 绑定线程和正在运行的事件循环。此后跨线程／循环访问抛 ExecutionContextError；原生对象自身不因此获得线程安全。

诊断（dev2）包含 owner_thread/current_thread 或 owner_loop/current_loop 标识；没有正在运行的循环时 current_loop=none。标识只用于当前进程诊断，不用于持久化身份或跨进程比较。ExecutionContextError 保留底层异常链。

测试读取 Session／原生对象必须在所属循环内；可以在循环内断言，或先提取普通数据再在外面断言。不能把 session 或原生对象带到新的 asyncio.run 中访问：

```python
async def observe_and_release(session):
    await session.start()
    observed = {"state": session.snapshot().state}
    report = await session.release()
    observed["released"] = report.complete
    return observed
# 在测试中用同一次 asyncio.run(observe_and_release(session)) 得到普通 dict 再断言。
```

同一 AsyncSession 的并发 start 由启动锁串行，成功后复用一次启动结果。此锁不是多工具调用的工作流锁。业务原先的工具／任务调度应保留；原生页面操作不能依赖共享库替它隔离。

可以在构造时传 `after_context_created`：

- SyncSession 使用普通函数，AsyncSession 使用 async 函数；参数为原生 context。
- 每次新建 context 执行一次，复用 start 不再次执行。
- 适合业务 init script／原生事件准备。失败走部分启动清理。
- 如回调自行创建页面，必须由业务保留引用，在 start 返回后显式 adopt 或登记；这些页仍由整个 context 最终持有并在 release 时关闭，但不会被当作恢复标签自动清理或提升为工作页。
- 禁止回调重入 start/release，库会拒绝；不要放验证码轮询等长流程。

`playwright_factory` 是注入 native context manager 工厂的高级接口，主要用于离线测试或明确的业务组装。返回对象须遵守与 sync_playwright/async_playwright 相同的 manager.start、driver.chromium.launch_persistent_context、driver.stop 及退出协议，并产生本 session 独占的 driver。它不能用于把共享 driver 冒充独占资源。

## 10. 将现有项目接入

Onshape 建议先适配 session.py，使业务 Session 持有一个 SyncSession 并委托 page/context/start/release；保留登录与应用 URL、重连、pacing、业务输出。工具 `_page()` 当前含单页清理，不能原样搬成公共 getter：在明确的工具准备边界调用 reconcile_pages，并验收活跃临时页保护行为。recorder 继续用原生事件，资源更换后明确重新绑定，不移除别人的监听。

淘宝使用 AsyncSession，保留 guard_captcha、登录、配置硬约束和工具锁。search.py 的当前页写入改 adopt_page；favorite/desc/qa 的页面返回与清理责任成对适配；物流页保持业务定义的复用和一次重建策略，仅更新临时资源登记。

单纯读取 context.pages 或操作原生 locator 不需要适配。检查所有 new_page/close 不是要求全部替换成公共 API，而是确保有一个明确最终所有者。

## 11. 回滚与维护

- 接入前保留旧业务版本、依赖锁和未提交差异备份。
- 每个适配阶段独立验证；回滚代码和 wheel 版本，不删除 profile。
- 业务对外工具状态的变更单独列出，不让库报告格式直接泄漏为公共 schema。
- 新能力同时更新本手册与契约测试；新增站点不在公共源码加入 if taobao/if onshape。
- 不用真实账号／模型／购物车验证库级错误处理，先使用 fake 和本地 HTML。

本手册没有赋予 agent 安装、生产修改、登录、付费或发布权限；执行权限来自当前用户任务和业务项目自身约束。
